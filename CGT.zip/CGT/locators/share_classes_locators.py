from selenium.webdriver.common.by import By


class ShareClassesLocators:
    share_classes_tab = (By.XPATH, "//a[@title='Share Classes']")
    share_classes_home=(By.XPATH,"(//div/span[text()='Share Classes'])[last()]")
    share_classes_new=(By.XPATH,"//a[@title='New']")
    save_button=(By.XPATH,"(//button[@name='SaveEdit'])[last()]")
    save_and_new=(By.XPATH,"(//button[@name='SaveAndNew'])[last()]")
    share_class_name=(By.XPATH,"//label[text()='Share Class Name']/..//input")
    asset_class = (By.XPATH, "//label[text()='Asset Class']/..//input")
    sub_asset_class = (By.XPATH, "//label[text()='Sub-Asset Class']/..//input")
    strategy = (By.XPATH, "//label[text()='Strategy']/..//input")
    product = (By.XPATH, "//label[text()='Product']/..//input")
    platform_suite = (By.XPATH, "//label[text()='Platform / Suite']/..//input")
    pooled_fund = (By.XPATH, "//label[text()='Pooled Fund']/..//input")
    income_distribution_type = (By.XPATH, "//label[text()='Income Distribution Type']/..//input")
    distribution_frequency = (By.XPATH, "//label[text()='Distribution Frequency']/..//input")
    share_class_record_page = (By.XPATH, "//h1/div[text()='Share Class']")