from selenium.webdriver.common.by import By


class HomeLocators:
    google_search = (By.XPATH, "//input[@name='q']")
    submit_button = (By.XPATH, "(//input[@name='btnK'])[last()]")
    images=(By.XPATH,"//a[text()='Images']")
    sigin=(By.XPATH,"//a[text()='Sign in']")
    imageverification=(By.XPATH,"//img[@alt='Google Images']")
    searchresult=(By.XPATH,"//h2/span[text()='Selenium']")
    email=(By.XPATH,"//input[@type='email']")

