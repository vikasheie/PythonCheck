from selenium.webdriver.common.by import By


class PlatformAvailabilityLocators:
    platform_availability_tab = (By.XPATH, "//a[@title='Platform Availability']")
    platform_availability_home=(By.XPATH,"//thead/tr/th[text()='Product']")
    header_count=(By.XPATH,"//thead/tr/th[contains(@class,'c-th')]")
    filter_values=(By.XPATH,"//div[text()='Filters']/../../../..//label")
    organizations_filter=(By.XPATH,"//label[text()='Organizations']/..//button/span")
    rating=(By.XPATH,"//label[text()='Rating']/..//button/span")
    sma_fee=(By.XPATH,"//label[text()='SMA Fee']/..//input")
    sma_minimum=(By.XPATH,"//label[text()='SMA Minimum']/..//input")
    product=(By.XPATH,"(//label[text()='Product']/..//input)[last()]")
    platform=(By.XPATH,"(//label[text()='Platform']/..//input)[last()]")
    organization=(By.XPATH,"(//label[text()='Organization']/..//input)[last()]")
    edit_platform_availability_cancel=(By.XPATH,"//button[text()='Cancel']")
