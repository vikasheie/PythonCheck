from selenium.webdriver.common.by import By


class LoginLocators:
    username = (By.XPATH, "//input[@type='email']")
    password = (By.XPATH, "//input[@type='password']")
    loginbutton=(By.XPATH, "//input[@type='submit']")
    registermobile=(By.XPATH,"//a[text()='Remind Me Later']")
    homepage=(By.XPATH,"//a[@title='Home']")
    otp = (By.XPATH, "//input[@name='tc']")
    otp_verify=(By.XPATH,"//input[@value='Verify']")

