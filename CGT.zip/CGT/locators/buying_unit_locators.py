from selenium.webdriver.common.by import By


class BuyingunitLocators:
    buying_unit_tab = (By.XPATH, "//a[@title='Buying Units']")
    buying_unit_home=(By.XPATH,"(//div/span[text()='Buying Units'])[last()]")
    buying_unit_new=(By.XPATH,"//a[@title='New']")
    sales_team_name=(By.XPATH,"//label[text()='Sales Team Name']/..//input")
    buying_unit_lead=(By.XPATH,"//label[text()='Buying Unit Lead']/..//input")
    save_button=(By.XPATH,"(//button[@name='SaveEdit'])[last()]")
    cancel_button=(By.XPATH,"(//button[@name='CancelEdit'])[last()]")
    buying_unit_record_page = (By.XPATH, "//h1/div[text()='Buying Unit']")
    assets_flow = (By.XPATH, "(//a[text()='Assets & Flows'])[last()]")
    line_of_business = (By.XPATH, "(//b[contains(text(),'Lines of Business')])[last()]")
    product = (By.XPATH,"(//b[contains(text(),'Lines of Business')])[last()]/../../../../../../../div[2]//b[contains(text(),'Product')]")
    retirement_product = (By.XPATH, "(//b[contains(text(),'Retirement Products')])[last()]")
