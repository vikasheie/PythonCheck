from selenium.webdriver.common.by import By


class PlatformsLocators:
    platforms_tab = (By.XPATH, "//a[@title='Platforms']")
    platforms_home=(By.XPATH,"(//div/span[text()='Platforms'])[last()]")
    platforms_new=(By.XPATH,"//a[@title='New']")
    record_next = (By.XPATH, "(//span[text()='Next'])[last()]")
    platform_name=(By.XPATH,"(//input[@name='Name'])[last()]")
    description=(By.XPATH,"(//label[text()='Description']/..//input)[last()]")
    parent_organization=(By.XPATH,"(//label[text()='Parent Organization']/../..//input)[last()]")
    platform_type=(By.XPATH,"//label[text()='Platform Type']/..//button/span")
    unsolicited=(By.XPATH,"//label[text()='Unsolicited']/..//button/span")
    status=(By.XPATH,"//label[text()='Status']/..//button/span")
    save=(By.XPATH,"//button[@name='SaveEdit']")
    save_and_new=(By.XPATH,"//button[@name='SaveAndNew']")
    platform_record_page = (By.XPATH, "//h1/div[text()='Platform']")
