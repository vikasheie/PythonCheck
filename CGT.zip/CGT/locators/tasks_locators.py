from selenium.webdriver.common.by import By


class TasksLocators:
    tasks_tab = (By.XPATH, "//a[@title='Tasks']")
    tasks_home=(By.XPATH,"(//span[text()='Recently Viewed'])[last()]")
    tasks_new=(By.XPATH,"//a[@title='New Task']")
    record_next=(By.XPATH,"(//span[text()='Next'])[last()]")
    new_task_dropdown=(By.XPATH,"//a[@title='Show one more action']")
    subject=(By.XPATH,"//label[text()='Subject']/../..//input")
    status=(By.XPATH,"(//span[text()='Status']/../..//a)[last()]")
    priority=(By.XPATH,"(//span[text()='Priority']/../..//a)[last()]")
    type=(By.XPATH,"//span[text()='Type']/../..//a")
    quality_contact=(By.XPATH,"//span[text()='Quality Contact']/../..//a")
    due_date=(By.XPATH,"//label[text()='Due Date']/../..//input")
    comments=(By.XPATH,"//span[text()='Comments']/../..//textarea")
    save_button=(By.XPATH,"(//span[text()='Save'])[last()]")
    save_and_new=(By.XPATH,"(//span[text()='Save & New'])[last()]")
    delete_button=(By.XPATH,"//a[@title='Delete']")
    delete_confirm=(By.XPATH,"(//span[text()='Delete'])[last()]")
    kanban_option_select=(By.XPATH,"(//button[@title='Select List View'])[last()]")
    kanban_search=(By.XPATH,"(//input[@role='combobox'])[last()]")
    remove_assignedto=(By.XPATH,"(//span[text()='Assigned To']/../..//a[@class='deleteAction'])[last()]")
    assigned_to=(By.XPATH,"(//span[text()='Assigned To']/../..//input)[last()]")
    refresh_button=(By.XPATH,"(//button[@name='refreshButton'])[last()]")
    tasks_edit=(By.XPATH,"(//div[text()='Edit'])[last()]")

