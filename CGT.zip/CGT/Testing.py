# import time
#
import time

import pyotp
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from config import properties
from pageObjects.contacts_page import ContactPage


# def multiselectmove(driver,option, listvalues):
#     action = ActionChains(driver)
#     if len(listvalues) > 1:
#         action.key_down(Keys.CONTROL).perform()
#         for i in listvalues:
#             dyanamiclocator = driver.find_element(By.XPATH, "//div[text()='" + option + "']/..//ul/li//span[@title='" + i + "']")
#             print(dyanamiclocator)
#             action.key_down(Keys.CONTROL).click(dyanamiclocator).perform()
#             # action.perform()
#         action.key_up(Keys.CONTROL).perform()
#     else:
#         dyanamiclocator = (By.XPATH, "//div[text()='" + option + "']/..//ul/li//span[@title='" + listvalues[0] + "']")
#         action.click(dyanamiclocator).perform()
#
#
driver = webdriver.Chrome(executable_path="C:\\Users\\vprath\\Downloads\\chromedriver_win32\\chromedriver.exe")
driver.get("https://oculusab--sit.my.salesforce.com/")
driver.find_element(By.XPATH,"//input[@type='email']").send_keys("vikash.pratheepan@alliancebernstein.com.sit")
driver.find_element(By.XPATH,"//input[@type='password']").send_keys("Arjun@1990")
driver.find_element(By.XPATH,"//input[@type='submit']").click()
time.sleep(25)
# element = driver.find_element_by_xpath("//div[text()='Select a Record Type']/../..//select")
# # element=dr
# sel = Select(element)
# sel.select_by_visible_text("Advisor Agreement")


# element = WebDriverWait(driver, 10).until(
#         EC.presence_of_element_located((By.XPATH, "//input[@type='email']"))
#     )
# driver.find_element(By.XPATH,"//input[@type='email']").send_keys("vikash.pratheepan@alliancebernstein.com.sit")
# driver.find_element(By.XPATH,"//input[@type='password']").send_keys("Arjun@1990")
# driver.find_element(By.XPATH,"//input[@type='submit']").click()
# totp=pyotp.TOTP(properties.key)
# print(totp.now())
# driver.find_element(By.XPATH,"//input[@name='tc']").send_keys(totp.now())
# driver.find_element(By.XPATH,"//input[@value='Verify']").click()
# time.sleep(40)
# multiselectmove(driver,"Designation",["CFA","CFP"])
# element=driver.find_element(By.XPATH,"//span[text()='Center of Influence']/../..//input")
# driver.execute_script("arguments[0].click();", element)
# value=driver.find_element(By.XPATH,"//label[text()='Parent Organization']/..//input").get_attribute('value')
# print(value)
# myOption=driver.find_element(By.XPATH,"//span[text()='Due Diligence']")
# myOption1=driver.find_element(By.XPATH,"//span[text()='Investment Comparison']")
#
# ActionChains(driver).click(myOption).perform()
# time.sleep(0.6)
# ActionChains(driver).key_down(Keys.CONTROL).click(myOption1).key_up(Keys.CONTROL).perform()
# driver.find_element(By.XPATH,"(//div[text()='Report Type']/..//button[@title='Move selection to Chosen'])").click()
# contact=ContactPage(driver,log=None)
# contact.preference_center_validation()
# contact.preference_center_communication_save("Office Phone")
# contact.preference_center_communication_validate("Office Phone")
# contact.preference_center_subscription_create()
# contact.preference_center_subscription_validate()
# contact.preference_center_productpreference_create()
# contact.preference_center_productpreference_validate()
# contact.preference_center_productliterature_create()
# contact.preference_center_productliterature_validate()
# driver.quit()

# //div[text()='Report Type']/..//span[text()='Due Diligence']
# (//div[text()='Report Type']/..//button[@title='Move selection to Chosen'])
# def flow_values(data):
#     flow_locator = (By.XPATH, "(//span[text()='Flows']/../../../..//span[text()=" + '"' + data + '"' + "])[last()]")
#     print(flow_locator)
#
# flow_values("Yesterday's")

# a={"b":10,"c":"Testing","d":10}
# f={"c":90,"e":50}
# a.update(f)
#
# from datetime import datetime
# value=str('{dt.month}/{dt.day}/{dt.year}'.format(dt = datetime.now()))
# print(value)
# print(type(value))
# EndDate = date.today() + timedelta(days=1)
# print(EndDate.strftime('%m/%d/%Y'))
# WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.NAME, "q")))
# mainmenu = driver.find_element_by_name("q")
# ActionChains(driver).move_to_element(mainmenu).perform()
# WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//a[@aria-label='Google apps']")))
# mainmenu1 = driver.find_elements_by_xpath("//a[@aria-label='Google apps']")
# ActionChains(driver).move_to_element(mainmenu).perform()
# submenu = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.LINK_TEXT, "Introduction")))
# tex="2 items • Sorted by Last Modified Date • "
# result=tex.split(" ")
# print(result)
# print(result[0])
options=["CFA","CFP"]
for i in options:
  # Find option that contains text equal to option
  to_select = driver.find_element_by_xpath("//span[@title='" + i + "']/../../..")
  time.sleep(1)
  driver.execute_script("window.scrollBy(0, 10);")
  # Use ActionChains
  ActionChains(driver).key_down(Keys.CONTROL).click(to_select).key_up(Keys.CONTROL).perform()
