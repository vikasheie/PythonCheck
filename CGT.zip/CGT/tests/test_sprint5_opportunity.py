from pageObjects.login_page import LoginPage
from pageObjects.opportunities_page import OpportunitiesPage
from locators.opportunities_locators import OpportunitiesLocators
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger


class TestSprint5Opportunity(BaseClass):

    def test_sprint5_CGT_23027(self):

        '''https://jiraprod.acml.com/browse/CGT-23027
        To verify "Manager Concentration" value  to Opportunity Win/Loss Reason picklist'''

        log = customLogger()
        jsonfilename="sprint5_CGT_23027.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        opportunityPage = OpportunitiesPage(self.driver, log)
        for i in list(data.keys()):
            opportunityPage.opportunities_home()
            log.info("Navigated to Opportunity home page")
            testdata = data[i]
            opportunityPage.opportunity_newrecord(i)
            log.info("Naviagated to New record page: " + i)
            opportunityPage.opportunity_fillrecord_jsonkeys(testdata)
            opportunityPage.save_opportunity()
            log.info("Created Opportunity record: "+i)
            opportunityPage.validate_opportunity_name(testdata)
            log.info("Validated Opportunity name for: "+i)
