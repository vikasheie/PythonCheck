import time

from pageObjects.login_page import LoginPage
from pageObjects.activity_notes_page import ActivityNotesPage
from pageObjects.organizations_page import OrganizationPage
from pageObjects.contacts_page import ContactPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.activity_notes_locators import ActivityNotesLocators


class TestSprint7ActivityNotes(BaseClass):

    def test_sprint7_CGT_23771(self):

        '''https://jiraprod.acml.com/browse/CGT-23771
        To Verify Updated requirements for 'Non Quality' Meeting notes '''

        log = customLogger()
        jsonfilename="sprint7_CGT_23771.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.javascriptClick(ActivityNotesLocators.quality_contact)
        activitynotesPage.check_mandatory_field_activity_notes(ActivityNotesLocators.title)
        activitynotesPage.check_mandatory_field(ActivityNotesLocators.activity_type)
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.purpose_disabled)
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.next_steps_disabled)
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.check_mandatory_field_activity_notes(ActivityNotesLocators.organization_attended)
        activitynotesPage.check_mandatory_field_activity_notes(ActivityNotesLocators.contacts_attended)
        activitynotesPage.save_activity_notes()
        assert False==activitynotesPage.isElementSelected(ActivityNotesLocators.quality_contact_checkbox)
        log.info("Created new Activity notes without quality contact and validated the mandatory fiels")
        edit_testdata = data["New Activity Quality"]
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.check_mandatory_field_activity_notes(ActivityNotesLocators.title)
        activitynotesPage.check_mandatory_field(ActivityNotesLocators.activity_type)
        activitynotesPage.check_mandatory_field(ActivityNotesLocators.purpose)
        activitynotesPage.check_mandatory_field(ActivityNotesLocators.next_steps)
        activitynotesPage.activity_notes_fillrecord_jsonkeys(edit_testdata)
        activitynotesPage.check_mandatory_field_activity_notes(ActivityNotesLocators.organization_attended)
        activitynotesPage.check_mandatory_field_activity_notes(ActivityNotesLocators.contacts_attended)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes with quality contact and validated the mandatory fiels")
        time.sleep(3)
        assert activitynotesPage.isElementSelected(ActivityNotesLocators.quality_contact_checkbox)

