from pageObjects.login_page import LoginPage
from pageObjects.contacts_page import ContactPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.contacts_locators import ContactLocators


class TestSprint6Contacts(BaseClass):



    def test_sprint6_CGT_23494(self):

        '''https://jiraprod.acml.com/browse/CGT-23494
        To Verify Focus Values'''

        log = customLogger()
        jsonfilename="sprint6_CGT_23494.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        jsonkeys = loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            contactPage.contact_home()
            log.info("Navigated to Contacts home page")
            contactPage.contact_newrecord(i)
            log.info("Navigated to New contacts page: "+i)
            assert testdata["Focus_Advisor_Values"]==contactPage.getListText(ContactLocators.focus_advisor_values)
            log.info("Validated Focus Advisor Values for: " + i)
            contactPage.contacts_fillrecord_jsonkeys(testdata)
            contactPage.save_contacts()
            log.info("Created new External Contact with Focus Advisor" + i)




