from pageObjects.login_page import LoginPage
from pageObjects.product_ratings_page import ProductRatingsPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.product_ratings_locators import ProductRatingsLocators


class TestSprint4ProductRatings(BaseClass):



    def test_sprint4_CGT_22716(self):

        '''To Verify Original Product Rating'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22716.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Platform Availability Rating"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        productratingPage=ProductRatingsPage(self.driver,log)
        productratingPage.prod_ratings_home()
        log.info("Navigated to Products ratings home page")
        productratingPage.prod_ratings_newrecord(testdata["Record_Type"])
        log.info("Navigated to New record page: "+testdata["Record_Type"])
        productratingPage.prod_ratings_fillrecord_jsonkeys(testdata)
        productratingPage.save_product_rating()
        log.info("Created Product record "+testdata["Record_Type"])

    def test_sprint4_CGT_22717(self):

        '''To verify Product Availability Ratings '''

        log = customLogger()
        jsonfilename="sprint4_CGT_22717.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Consultant Rating"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        productratingPage=ProductRatingsPage(self.driver,log)
        productratingPage.prod_ratings_home()
        log.info("Navigated to Products ratings home page")
        productratingPage.prod_ratings_newrecord(testdata["Record_Type"])
        log.info("Navigated to New record page: "+testdata["Record_Type"])
        productratingPage.prod_ratings_fillrecord_jsonkeys(testdata)
        productratingPage.save_product_rating()
        log.info("Created Product record "+testdata["Record_Type"])
        productratingPage.prod_ratings_verify_jsonkeys(testdata)
        log.info("Verified Product record " + testdata["Record_Type"])
        productratingPage.delete_product_rating()
        log.info("Deleted Product record " + testdata["Record_Type"])

    def test_sprint4_CGT_22719(self):

        '''To verify Standardized Product Rating '''

        log = customLogger()
        jsonfilename="sprint4_CGT_22719.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Platform Availability Rating"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        productratingPage=ProductRatingsPage(self.driver,log)
        productratingPage.prod_ratings_home()
        log.info("Navigated to Products ratings home page")
        productratingPage.prod_ratings_newrecord(testdata["Record_Type"])
        log.info("Navigated to New record page: "+testdata["Record_Type"])
        assert set(testdata["Rating_Values"])==productratingPage.get_spandropdown_values(ProductRatingsLocators.rating)
        productratingPage.prod_ratings_fillrecord_jsonkeys(testdata)
        productratingPage.save_product_rating()

    def test_sprint4_CGT_22720(self):

        '''To Verify Product Rating Last Updated Date/By '''

        log = customLogger()
        jsonfilename="sprint4_CGT_22720.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Platform Availability Rating"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        jsonkeys=loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            productratingPage=ProductRatingsPage(self.driver,log)
            productratingPage.prod_ratings_home()
            log.info("Navigated to Products ratings home page")
            productratingPage.prod_ratings_newrecord(i)
            productratingPage.prod_ratings_fillrecord_jsonkeys(testdata)
            productratingPage.save_product_rating()
            edit_testdata=data["Edit "+i]
            productratingPage.prod_ratings_editrecord_jsonkeys(edit_testdata)
            productratingPage.save_product_rating()
            testdata.update(edit_testdata)
            productratingPage.prod_ratings_verify_jsonkeys(testdata)
            new_edit_testdata = data["Edit1 " + i]
            new_edit_testdata["Rating_Last_Confirmed_On"]=productratingPage.getYesterdayDate()
            productratingPage.prod_ratings_editrecord_jsonkeys(new_edit_testdata)
            productratingPage.save_product_rating()
            testdata.update(new_edit_testdata)
            productratingPage.prod_ratings_verify_jsonkeys(testdata)
