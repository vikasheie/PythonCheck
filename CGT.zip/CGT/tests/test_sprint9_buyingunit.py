from pageObjects.login_page import LoginPage
from pageObjects.buying_unit_page import BuyingunitPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.buying_unit_locators import BuyingunitLocators


class TestSprint9BuyingUnit(BaseClass):



    def test_sprint9_CGT_24634(self):

        '''https://jiraprod.acml.com/browse/CGT-24634
        To Verify AUM & Flow Attributes in Buying Unit '''

        log = customLogger()
        jsonfilename="sprint9_CGT_24634.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        buyingunitPage=BuyingunitPage(self.driver,log)
        testdata = data["Buying Unit"]
        buyingunitPage.buying_unit_home()
        log.info("Navigated to Buying Unit home page")
        buyingunitPage.buying_unit_newrecord()
        log.info("Navigated to New Buying Unit page")
        buyingunitPage.buying_unit_fillrecord_jsonkeys(testdata)
        buyingunitPage.save_buyingunit()
        log.info("Created New Buying Unit")
        buyingunitPage.elementClick(BuyingunitLocators.assets_flow)
        buyingunitPage.asset_flow_validation(testdata)
        log.info("Validated Asset and Flow values of Buying unit")
        buyingunitPage.webScroll(direction="down")
        assert buyingunitPage.waitForElementDisplay(BuyingunitLocators.line_of_business)
        assert buyingunitPage.waitForElementDisplay(BuyingunitLocators.product)
        assert buyingunitPage.waitForElementDisplay(BuyingunitLocators.retirement_product)
        log.info("Verified Asset and Flow related list for Buying Unit")
