import time

from pageObjects.login_page import LoginPage
from pageObjects.organizations_page import OrganizationPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.organization_locators import OrganizationLocators


class TestSprint5Organizations(BaseClass):


    def test_sprint4_CGT_23025(self):

        '''https://jiraprod.acml.com/browse/CGT-23025
        To Verify Secondary Address Fields for Org Record Creation'''

        log = customLogger()
        jsonfilename="sprint5_CGT_23025.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        jsonkeys=loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            orgPage=OrganizationPage(self.driver,log)
            orgPage.organization_home()
            log.info("Navigated to Organization home page")
            orgPage.organization_newrecord(i)
            log.info("Navigated to Organization new record page: "+i)
            orgPage.waitForElementDisplay(OrganizationLocators.visiting_address)
            orgPage.waitForElementDisplay(OrganizationLocators.correspondance_address)
            log.info("verified presence of Address Information in: "+i)
            orgPage.organization_fillrecord_jsonkeys(testdata)
            orgPage.save_organization()
            log.info("created new Organization: "+i)
            time.sleep(2)

    def test_sprint4_CGT_23024(self):

        '''https://jiraprod.acml.com/browse/CGT-23024
        To Verify ORG Hierarchy level field'''

        log = customLogger()
        jsonfilename="sprint5_CGT_23024.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        jsonkeys=loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            orgPage=OrganizationPage(self.driver,log)
            orgPage.organization_home()
            log.info("Navigated to Organization home page")
            orgPage.organization_newrecord(i)
            log.info("Navigated to Organization new record page: "+i)
            assert testdata["Organization_Hierarchy_Level_Values"]==orgPage.get_listdropdown_values(OrganizationLocators.organization_hierarchy)
            log.info("verified fields of Organization Hierachcy level in: "+i)
            orgPage.organization_fillrecord_jsonkeys(testdata)
            orgPage.save_organization()
            log.info("created new Organization: "+i)
            time.sleep(2)