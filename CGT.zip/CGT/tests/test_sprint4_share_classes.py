from pageObjects.login_page import LoginPage
from pageObjects.share_classes_page import ShareClassesPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger


class TestSprint4ShareClasses(BaseClass):



    def test_sprint4_CGT_22602(self):

        '''https://jiraprod.acml.com/browse/CGT-22602
        To verify Share class Object'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22602.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Share Classes"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        shareclassPage=ShareClassesPage(self.driver,log)
        shareclassPage.share_classes_home()
        log.info("Navigated to Share Classes home page")
        shareclassPage.share_classes_newrecord()
        log.info("Navigated to New Share Class page")
        shareclassPage.share_class_fillrecord_jsonkeys(testdata)
        shareclassPage.save_share_classes()
        log.info("Created New Share Class record")