import time

from pageObjects.login_page import LoginPage
from pageObjects.contacts_page import ContactPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.contacts_locators import ContactLocators


class TestSprint7Contacts(BaseClass):



    def test_sprint7_CGT_23714(self):

        '''https://jiraprod.acml.com/browse/CGT-23714
        To Verify Employee ID Field in Employee Contact'''

        log = customLogger()
        jsonfilename="sprint7_CGT_23714.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        testdata = data["Employee"]
        contactPage.contact_home()
        log.info("Navigated to Contacts home page")
        contactPage.contact_newrecord(testdata["Record_Type"])
        log.info("Navigated to New contacts page: " + testdata["Record_Type"])
        contactPage.contacts_fillrecord_jsonkeys(testdata)
        contactPage.save_contacts()
        log.info("Created new Contact" + testdata["Record_Type"])
        contactPage.elementClick(ContactLocators.contacts_edit)
        edit_testdata=data["Edit Employee"]
        contactPage.contacts_fillrecord_jsonkeys(edit_testdata)
        contactPage.save_contacts()
        log.info("Edited Employee id in Contact" + testdata["Record_Type"])
        old_id=edit_testdata["Employee_ID"]
        testdata["Employee_ID"]=old_id
        contactPage.contact_home()
        log.info("Navigated to Contacts home page")
        contactPage.contact_newrecord(testdata["Record_Type"])
        log.info("Navigated to New contacts page: " + testdata["Record_Type"])
        contactPage.contacts_fillrecord_jsonkeys(testdata)
        contactPage.elementClick(ContactLocators.save_button)
        contactPage.waitForElementDisplay(ContactLocators.duplicate_employee_id)


    def test_sprint7_CGT_23711(self):

        '''https://jiraprod.acml.com/browse/CGT-23711
        To verify Two Email Picklist Values in Comm Preferences Tab'''

        log = customLogger()
        jsonfilename="sprint7_CGT_23711.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        testdata = data["External Contact"]
        contactPage.contact_home()
        log.info("Navigated to Contacts home page")
        contactPage.contact_newrecord(testdata["Record_Type"])
        log.info("Navigated to New contacts page: " + testdata["Record_Type"])
        contactPage.contacts_fillrecord_jsonkeys(testdata)
        contactPage.save_contacts()
        log.info("Created new Contact" + testdata["Record_Type"])
        contactPage.elementClick(ContactLocators.preference_center)
        assert testdata["Preferred_communication_channel_values"]==contactPage.get_buttondropdown_values(ContactLocators.preferred_communication_channel)

    def test_sprint7_CGT_23749(self):

        '''https://jiraprod.acml.com/browse/CGT-23749
        To Verify Contact Subscriptions (Remove/Expire)'''

        log = customLogger()
        jsonfilename="sprint7_CGT_23749.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        testdata = data["External Contact"]
        contactPage.contact_home()
        log.info("Navigated to Contacts home page")
        contactPage.contact_newrecord(testdata["Record_Type"])
        log.info("Navigated to New contacts page: " + testdata["Record_Type"])
        contactPage.contacts_fillrecord_jsonkeys(testdata)
        contactPage.save_contacts()
        log.info("Created new Contact" + testdata["Record_Type"])
        contactPage.elementClick(ContactLocators.preference_center)
        assert contactPage.elementClick(ContactLocators.product_preferences)
        product_name=contactPage.getText(ContactLocators.product_preferences_productname)
        assert contactPage.javascriptClick(ContactLocators.preference_cancel_button)
        contactPage.preference_center_productpreference_create()
        contactPage.preference_center_subscription_create()
        time.sleep(1)
        contactPage.elementClick(ContactLocators.marketing_tab)
        contactPage.webScroll(direction="down")
        assert product_name==contactPage.contact_product_preference_history(option=1)
        assert "Interested" == contactPage.contact_product_preference_history(option=2)
        assert "Not Interested" == contactPage.contact_product_preference_history(option=3)
        log.info("Validated the Product preference selection matches with Contact Product Preference History")
        assert testdata["Subscription_Values"]==contactPage.contact_marketing_preference_history(option=1)
        assert testdata["Subsription_New_Values"]==contactPage.contact_marketing_preference_history(option=2)
        assert testdata["Subscription_Old_Values"]==contactPage.contact_marketing_preference_history(option=3)
        assert testdata["Subscription_Preference_Type"]==contactPage.contact_marketing_preference_history(option=4)
        log.info("Validated the Subscription selection matches with Contact Marketing Preference History")

    def test_sprint7_CGT_23738(self):

        '''https://jiraprod.acml.com/browse/CGT-23738
        To verify Two Email Picklist Values in Comm Preferences Tab'''

        log = customLogger()
        jsonfilename="sprint7_CGT_23711.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        testdata = data["External Contact"]
        contactPage.contact_home()
        log.info("Navigated to Contacts home page")
        contactPage.contact_newrecord(testdata["Record_Type"])
        log.info("Navigated to New contacts page: " + testdata["Record_Type"])
        type_values=contactPage.get_buttondropdown_values(ContactLocators.type)
        print(type_values)
        dict={}
        contactPage.elementClick(ContactLocators.type)
        for i in type_values:
            if i!="--None--" or i!='':
                contactPage.spantypedropdown(ContactLocators.type, option=i)
                time.sleep(1)
                sub_type_values = contactPage.get_buttondropdown_values(ContactLocators.sub_type)
                contactPage.elementClick(ContactLocators.sub_type)
                dict[i] = sub_type_values
                print("-------------------------------------")
                print(i)
                print(sub_type_values)
                print("-------------------------------------")
        # contactPage.contacts_fillrecord_jsonkeys(testdata)
        # contactPage.save_contacts()
        log.info("Created new External Contact")
        contactPage.elementClick(ContactLocators.show_more_actions)
        contactPage.elementClick(ContactLocators.move_contact)
        move_type_values = contactPage.get_buttondropdown_values(ContactLocators.type)
        print(type_values)
        print(move_type_values)
        dict_move = {}
        contactPage.elementClick(ContactLocators.type)
        for j in move_type_values:
            if j != "--None--" or j != '':
                contactPage.spantypedropdown(ContactLocators.type, option=j)
                time.sleep(1)
                move_sub_type_values = contactPage.get_buttondropdown_values(ContactLocators.sub_type)
                contactPage.javascriptClick(ContactLocators.sub_type)
                dict_move[j] = move_sub_type_values
                print("**************************************")
                print(j)
                print(move_sub_type_values)
                print("***************************************")
        print(dict)
        print(dict_move)
        assert dict==dict_move