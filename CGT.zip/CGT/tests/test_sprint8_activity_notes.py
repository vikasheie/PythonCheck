import time

from pageObjects.login_page import LoginPage
from pageObjects.activity_notes_page import ActivityNotesPage
from pageObjects.organizations_page import OrganizationPage
from pageObjects.contacts_page import ContactPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.activity_notes_locators import ActivityNotesLocators


class TestSprint8ActivityNotes(BaseClass):

    def test_sprint8_CGT_23978(self):

        '''https://jiraprod.acml.com/browse/CGT-23978
        To Verify additional 'Next Steps' picklist value on the Meeting Note object named "Send Seismic Materials"'''

        log = customLogger()
        jsonfilename="sprint8_CGT_23978.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes with Next step value as Send Seismic Materials")
        edit_testdata = data["Edit New Activity"]
        # activitynotesPage.activity_notes_home()
        # log.info("Navigated to Activity Notes home page")
        # activitynotesPage.activity_notes_newrecord()
        # log.info("Navigated to New Activity Notes page")
        activitynotesPage.waitForElementClick(ActivityNotesLocators.activity_notes_edit)
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit_testdata)
        activitynotesPage.save_activity_notes()
        log.info("Edited Activity notes with Next step value as Send Seismic Materials")


