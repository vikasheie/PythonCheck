import time

from pageObjects.login_page import LoginPage
from pageObjects.activity_notes_page import ActivityNotesPage
from pageObjects.organizations_page import OrganizationPage
from pageObjects.contacts_page import ContactPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.activity_notes_locators import ActivityNotesLocators


class TestSprint5ActivityNotes(BaseClass):

    def test_sprint5_CGT_22866(self):

        '''https://jiraprod.acml.com/browse/CGT-22866
        To Verify Campaign to Meeting Note Relationship'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22866.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes with multiple Campaign")
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.multiple_campaigns)
        campaign_list=activitynotesPage.getElementList(ActivityNotesLocators.multiple_campaigns)
        verification_list=[]
        for i in campaign_list:
            verification_list.append(i.text)
        assert testdata["Campaigns_Discussed"]==verification_list
        activitynotesPage.verify_activity_notes_inrelated(ActivityNotesLocators.multiple_campaigns,testdata["Title"])


    def test_sprint5_CGT_22864(self):

        '''https://jiraprod.acml.com/browse/CGT-22864
        To verify Spell check - 'Organizations' In Meeting Note Creation Screen'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22864.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.organization_american_spellcheck)
        log.info("Verified the Organization spell check")
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes")
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.organization_american_spellcheck_tablerightpanel)
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.organization_american_spellcheck_righpanel)
        log.info("Verified the Organization spell check after creating activity notes")
