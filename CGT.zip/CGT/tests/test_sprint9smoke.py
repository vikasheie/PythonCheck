import os
import time

from pageObjects.contacts_page import ContactPage
from pageObjects.login_page import LoginPage
from pageObjects.organizations_page import OrganizationPage
from pageObjects.opportunities_page import OpportunitiesPage
from pageObjects.campaigns_page import CampaignPage
from pageObjects.platforms_page import PlatformsPage
from pageObjects.cases_page import CasesPage
from pageObjects.products_page import ProdcutsPage
from pageObjects.product_ratings_page import ProductRatingsPage
from pageObjects.tasks_page import TasksPage
from pageObjects.activity_notes_page import ActivityNotesPage
from pageObjects.platform_availability_page import PlatformAvailabilityPage
from pageObjects.buying_unit_page import BuyingunitPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger


class TestSprint9smoke(BaseClass):



    def test_UAT_Smoke(self):

        log = customLogger()
        data = self.getJsonData("Smoke.json")
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        # productPage = ProdcutsPage(self.driver, log)
        # productPage.product_allrecords_create_verify(data)
        # orgPage=OrganizationPage(self.driver,log)
        # orgPage.organization_allrecords_create_verify(data)
        # contactPage = ContactPage(self.driver, log)
        # contactPage.contacts_allrecord_create_verify(data)
        # opportunityPage=OpportunitiesPage(self.driver,log)
        # opportunityPage.opportunity_allrecord_create_verify(data)
        # campaignPage=CampaignPage(self.driver,log)
        # campaignPage.campaigns_allrecord_create_verify(data)
        casePage=CasesPage(self.driver,log)
        casePage.cases_allrecords_create_verify(data)
        # tasksPage=TasksPage(self.driver,log)
        # tasksPage.tasks_create_verify(data)
        # activitynotesPage=ActivityNotesPage(self.driver,log)
        # activitynotesPage.activity_notes_create_verify(data)
        # platformPage = PlatformsPage(self.driver, log)
        # platformPage.platform_create_record(data)
        # prodratingPage = ProductRatingsPage(self.driver, log)
        # prodratingPage.prod_ratings_allrecords_create_verify(data)
        # platformavailabilityPage=PlatformAvailabilityPage(self.driver,log)
        # platformavailabilityPage.platform_availability_validation(data)
        # buyingunitPage=BuyingunitPage(self.driver,log)
        # buyingunitPage.getkeycheck(data)


