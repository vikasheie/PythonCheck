from pageObjects.login_page import LoginPage
from pageObjects.opportunities_page import OpportunitiesPage
from locators.opportunities_locators import OpportunitiesLocators
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger


class TestSprint4Opportunity(BaseClass):



    def test_sprint4_CGT_22462(self):

        '''To Verify Platform Field To Platform Placement Opportunity Record Type'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22462.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Platform Placement"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        opportunityPage=OpportunitiesPage(self.driver,log)
        opportunityPage.opportunities_home()
        log.info("Navigated to Opportunity home page")
        opportunityPage.opportunity_newrecord(testdata["Record_Type"])
        log.info("Naviagated to New record page: "+testdata["Record_Type"])
        opportunityPage.opportunity_fillrecord_jsonkeys(testdata)
        log.info("Verified the Platform field presence")
        opportunityPage.save_opportunity()
        log.info("Created Platform Placement Opportunity record")

    def test_sprint4_CGT_22841(self):

        '''To verify Advisor Agreement Opportunity - Probability'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22841.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Advisor Agreement"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        opportunityPage=OpportunitiesPage(self.driver,log)
        opportunityPage.opportunities_home()
        log.info("Navigated to Opportunity home page")
        opportunityPage.opportunity_newrecord(testdata["Record_Type"])
        log.info("Naviagated to New record page: "+testdata["Record_Type"])
        opportunityPage.opportunity_fillrecord_jsonkeys(testdata)
        assert "10%"==opportunityPage.getAttributeValue(OpportunitiesLocators.probability)
        log.info("Verified the probability percentage is 10")

    def test_sprint4_CGT_22461(self):

        '''To verify Updated Opportunity Naming Convention'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22461.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        opportunityPage = OpportunitiesPage(self.driver, log)
        for i in list(data.keys()):
            opportunityPage.opportunities_home()
            log.info("Navigated to Opportunity home page")
            testdata = data[i]
            opportunityPage.opportunity_newrecord(i)
            log.info("Naviagated to New record page: " + i)
            opportunityPage.opportunity_fillrecord_jsonkeys(testdata)
            opportunityPage.save_opportunity()
            log.info("Created Opportunity record: "+i)
            opportunityPage.validate_opportunity_name(testdata)
            log.info("Validated Opportunity name for: "+i)

    def test_sprint4_CGT_22725(self):

        '''https://jiraprod.acml.com/browse/CGT-22725
        To verify Purpose field values in platform Placement Opportunity'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22725.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Platform Placement"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        opportunityPage=OpportunitiesPage(self.driver,log)
        opportunityPage.opportunities_home()
        log.info("Navigated to Opportunity home page")
        opportunityPage.opportunity_newrecord(testdata["Record_Type"])
        log.info("Naviagated to New record page: "+testdata["Record_Type"])
        opportunityPage.opportunity_fillrecord_jsonkeys(testdata)