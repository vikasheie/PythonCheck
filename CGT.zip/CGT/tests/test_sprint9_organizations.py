import time

from pageObjects.login_page import LoginPage
from pageObjects.organizations_page import OrganizationPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.organization_locators import OrganizationLocators


class TestSprint9Organizations(BaseClass):


    def test_sprint9_CGT_24602(self):

        '''https://jiraprod.acml.com/browse/CGT-24602
        To Verify Secondary Address Fields for Org Record Creation'''

        log = customLogger()
        jsonfilename="sprint9_CGT_24602.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        jsonkeys=loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            orgPage=OrganizationPage(self.driver,log)
            orgPage.organization_home()
            log.info("Navigated to Organization home page")
            orgPage.organization_newrecord(i)
            log.info("Navigated to Organization new record page: "+i)
            orgPage.waitForElementDisplay(OrganizationLocators.visiting_address)
            orgPage.waitForElementDisplay(OrganizationLocators.correspondance_address)
            log.info("verified presence of Address Information in: "+i)
            orgPage.organization_fillrecord_jsonkeys(testdata)
            orgPage.save_organization()
            log.info("created new Organization: "+i)
            time.sleep(1)
            assert orgPage.elementClick(OrganizationLocators.related_tab)
            time.sleep(1)
            assert orgPage.javascriptClick(OrganizationLocators.contact_list)
            time.sleep(1)
            assert orgPage.elementClick(OrganizationLocators.contact_AUM_dropdown_button)
            assert orgPage.waitForElementDisplay(OrganizationLocators.contact_AUM)
            assert orgPage.waitForElementDisplay(OrganizationLocators.contact_ytd_gross_sale)
            log.info("Verified the presence of AUM and YTD Gross Sale value in record: " + i)


    def test_sprint9_CGT_24607(self):

        '''https://jiraprod.acml.com/browse/CGT-24607
        To verify Organization AUM & Flow Attributes'''

        log = customLogger()
        jsonfilename="sprint9_CGT_24607.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        jsonkeys=loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            orgPage=OrganizationPage(self.driver,log)
            orgPage.organization_home()
            log.info("Navigated to Organization home page")
            orgPage.organization_newrecord(i)
            log.info("Navigated to Organization new record page: "+i)
            orgPage.waitForElementDisplay(OrganizationLocators.visiting_address)
            orgPage.waitForElementDisplay(OrganizationLocators.correspondance_address)
            log.info("verified presence of Address Information in: "+i)
            orgPage.organization_fillrecord_jsonkeys(testdata)
            orgPage.save_organization()
            log.info("created new Organization: "+i)
            time.sleep(1)
            orgPage.asset_flow_validation(testdata)
            log.info("Verified Asset and Flow values in: " + i)
            orgPage.webScroll(direction="down")
            time.sleep(0.8)
            assert orgPage.waitForElementDisplay(OrganizationLocators.line_of_business)
            assert orgPage.waitForElementDisplay(OrganizationLocators.product)
            assert orgPage.waitForElementDisplay(OrganizationLocators.retirement_product)
            log.info("Verified Asset and Flow related list: " + i)
