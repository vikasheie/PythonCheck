from pageObjects.login_page import LoginPage
from pageObjects.contacts_page import ContactPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger


class TestSprint5Contacts(BaseClass):



    def test_sprint5_CGT_22912(self):

        '''https://jiraprod.acml.com/browse/CGT-22912
        To Verify Recurring Subscriptions'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22912.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["External Contact"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        contactPage.contact_home()
        log.info("Navigated to Contacts home page")
        contactPage.contact_newrecord(testdata["Record_Type"])
        log.info("Navigated to New contacts page")
        contactPage.contacts_fillrecord_jsonkeys(testdata)
        contactPage.save_contacts()
        log.info("Created New External Contact")
        contactPage.preference_center_subscription_create()
        contactPage.preference_center_subscription_validate()
        log.info("Created and Validated the Subscription")

    def test_sprint5_CGT_22889(self):

        '''https://jiraprod.acml.com/browse/CGT-22889
        To Verify Product Preference Updates'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22889.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["External Contact"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        contactPage.contact_home()
        log.info("Navigated to Contacts home page")
        contactPage.contact_newrecord(testdata["Record_Type"])
        log.info("Navigated to New contacts page")
        contactPage.contacts_fillrecord_jsonkeys(testdata)
        contactPage.save_contacts()
        log.info("Created New External Contact")
        contactPage.preference_center_productpreference_create()
        contactPage.preference_center_productpreference_validate()
        log.info("Selected and Validated the Product Preference")
        contactPage.preference_center_productpreference_create()
        contactPage.preference_center_productpreference_validate(type="unselect")
        log.info("Unselected and Validated the Product Preference")

    def test_sprint5_CGT_22884(self):

        '''https://jiraprod.acml.com/browse/CGT-22884
        To Verify Product Preferences Filter'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22884.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["External Contact"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        contactPage.contact_home()
        log.info("Navigated to Contacts home page")
        contactPage.contact_newrecord(testdata["Record_Type"])
        log.info("Navigated to New contacts page")
        contactPage.contacts_fillrecord_jsonkeys(testdata)
        contactPage.save_contacts()
        log.info("Created New External Contact")
        contactPage.preference_center_productpreference_create(option="filter",data=testdata["Product_Filter"])
        contactPage.preference_center_productpreference_validate(option="filter",data=testdata["Product_Filter"])
        log.info("Selected and Validated the Product Preference filter")
        contactPage.preference_center_productpreference_create(option="filter",data=testdata["Product_Filter"])
        contactPage.preference_center_productpreference_validate(type="unselect",option="filter",data=testdata["Product_Filter"])
        log.info("Unselected and Validated the Product Preference filter")
