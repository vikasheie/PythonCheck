import time

from pageObjects.login_page import LoginPage
from pageObjects.contacts_page import ContactPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.contacts_locators import ContactLocators


class TestSprint9Contacts(BaseClass):



    def test_sprint9_CGT_24623(self):

        '''https://jiraprod.acml.com/browse/CGT-24623
        To Verify AUM & Flow Attributes in Contact record '''

        log = customLogger()
        jsonfilename="sprint9_CGT_24623.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        jsonkeys = loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            contactPage.contact_home()
            log.info("Navigated to Contacts home page")
            contactPage.contact_newrecord(i)
            log.info("Navigated to New contacts page: "+i)
            contactPage.contacts_fillrecord_jsonkeys(testdata)
            contactPage.save_contacts()
            log.info("Created New Contact: "+i)
            if i=="Employee":
                assert False==contactPage.waitForElementDisplay(ContactLocators.assets_flow,timeout=3)
                log.info("Asset and Flow is not found in : " + i)
            else:
                contactPage.elementClick(ContactLocators.assets_flow)
                contactPage.asset_flow_validation(testdata)
                log.info("Validated the Asset and Flow values for : " + i)
                contactPage.webScroll(direction="down")
                assert contactPage.waitForElementDisplay(ContactLocators.line_of_business)
                assert contactPage.waitForElementDisplay(ContactLocators.product)
                assert contactPage.waitForElementDisplay(ContactLocators.retirement_product)
                log.info("Verified Asset and Flow related list: " + i)


    def test_sprint9_CGT_24622(self):

        '''https://jiraprod.acml.com/browse/CGT-24622
        To Verify Updated Attributes to Buying unit related list in Contact record '''

        log = customLogger()
        jsonfilename="sprint9_CGT_24622.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        contactPage=ContactPage(self.driver,log)
        jsonkeys = loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            contactPage.contact_home()
            log.info("Navigated to Contacts home page")
            contactPage.contact_newrecord(i)
            log.info("Navigated to New contacts page: "+i)
            contactPage.contacts_fillrecord_jsonkeys(testdata)
            contactPage.save_contacts()
            log.info("Created New Contact: "+i)
            time.sleep(1)
            contactPage.javascriptClick(ContactLocators.more_button)
            time.sleep(1)
            contactPage.elementClick(ContactLocators.related_tab)
            contactPage.webScroll(direction="down")
            contactPage.javascriptClick(ContactLocators.buying_unit)
            contactPage.waitForElementDisplay(ContactLocators.buying_unit_aum)
            contactPage.waitForElementDisplay(ContactLocators.buying_unit_ytd_gross)
            log.info("Validated the Presence of AUM and YTD Gross Sales attribute in Buying unit table")

