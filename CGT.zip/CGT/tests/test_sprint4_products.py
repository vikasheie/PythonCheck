from pageObjects.login_page import LoginPage
from pageObjects.products_page import ProdcutsPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.product_locators import ProductLocators


class TestSprint4Products(BaseClass):



    def test_sprint4_CGT_22594(self):

        '''https://jiraprod.acml.com/browse/CGT-22594
        To Verify Asset class record type in products'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22594.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Asset Class"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        productsPage=ProdcutsPage(self.driver,log)
        productsPage.product_home()
        log.info("Navigated to Products home page")
        productsPage.product_newrecord(testdata["Record_Type"])
        log.info("Navigated to New record page: "+testdata["Record_Type"])
        productsPage.product_fillrecord_jsonkeys(testdata)
        productsPage.save_product()
        log.info("Created Product record "+testdata["Record_Type"])

    def test_sprint4_CGT_22596(self):

        '''https://jiraprod.acml.com/browse/CGT-22596
        To Verify Strategies record type in Products'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22596.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Strategy"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        productsPage=ProdcutsPage(self.driver,log)
        productsPage.product_home()
        log.info("Navigated to Products home page")
        productsPage.product_newrecord(testdata["Record_Type"])
        log.info("Navigated to New record page: "+testdata["Record_Type"])
        productsPage.check_mandatory_field(ProductLocators.name)
        productsPage.check_mandatory_field(ProductLocators.asset_class)
        productsPage.check_mandatory_field(ProductLocators.sub_asset_class)
        # productsPage.check_mandatory_field(ProductLocators.platform_suite)
        productsPage.product_fillrecord_jsonkeys(testdata)
        productsPage.save_product()
        log.info("Created Product record "+testdata["Record_Type"])

    def test_sprint4_CGT_22600(self):

        '''https://jiraprod.acml.com/browse/CGT-22600
        To verify Products record type in Products'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22600.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Product"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        productsPage=ProdcutsPage(self.driver,log)
        productsPage.product_home()
        log.info("Navigated to Products home page")
        productsPage.product_newrecord(testdata["Record_Type"])
        log.info("Navigated to New record page: "+testdata["Record_Type"])
        productsPage.check_mandatory_field(ProductLocators.name)
        productsPage.check_mandatory_field(ProductLocators.asset_class)
        productsPage.check_mandatory_field(ProductLocators.sub_asset_class)
        # productsPage.check_mandatory_field(ProductLocators.platform_suite)
        productsPage.product_fillrecord_jsonkeys(testdata)
        productsPage.save_product()
        log.info("Created Product record "+testdata["Record_Type"])

    def test_sprint4_CGT_22463(self):

        '''https://jiraprod.acml.com/browse/CGT-22463
        To verify Sub asset class'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22463.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Sub Asset Class"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        productsPage=ProdcutsPage(self.driver,log)
        productsPage.product_home()
        log.info("Navigated to Products home page")
        productsPage.product_newrecord(testdata["Record_Type"])
        log.info("Navigated to New record page: "+testdata["Record_Type"])
        productsPage.check_mandatory_field(ProductLocators.asset_class)
        productsPage.check_mandatory_field(ProductLocators.name)
        productsPage.check_mandatory_field(ProductLocators.platform_suite)
        log.info("Checked the mandatory fields  Asset Class, Platform Suite")

    def test_sprint4_CGT_22598(self):

        '''https://jiraprod.acml.com/browse/CGT-22598
        To verify Platform/Suite record type in Products'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22598.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Platform / Suite"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        productsPage=ProdcutsPage(self.driver,log)
        productsPage.product_home()
        log.info("Navigated to Products home page")
        productsPage.product_newrecord(testdata["Record_Type"])
        log.info("Navigated to New record page: "+testdata["Record_Type"])
        productsPage.check_mandatory_field(ProductLocators.asset_class)
        log.info("Checked the mandatory fields  Asset Class")
        productsPage.product_fillrecord_jsonkeys(testdata)
        log.info("Created new PlatformSuite Record")