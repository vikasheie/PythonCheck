from pageObjects.login_page import LoginPage
from pageObjects.tasks_page import TasksPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger


class TestSprint4Tasks(BaseClass):



    def test_sprint4_CGT_22465(self):

        '''https://jiraprod.acml.com/browse/CGT-22465
        To Verify Task Queue (Tasks I Have Assigned)'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22465.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Task"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        tasksPage=TasksPage(self.driver,log)
        tasksPage.tasks_home()
        log.info("Navigated to Tasks home page")
        tasksPage.tasks_newrecord()
        log.info("Navigated to New tasks page")
        tasksPage.tasks_fillrecord_jsonkeys(testdata)
        tasksPage.save_tasks()
        tasksPage.confirm_task_created(testdata)
        log.info("Created New task and assigned to another person")
        tasksPage.select_kanban(testdata["Kanban_Option"])
        tasksPage.verify_record_presence_inkanban(testdata["Subject"])
        log.info("Verified the task present in kanban view")


    def test_sprint4_CGT_22469(self):

        '''https://jiraprod.acml.com/browse/CGT-22649
        To Verify Task Queue (My Tasks)'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22649.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Task"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        tasksPage=TasksPage(self.driver,log)
        tasksPage.tasks_home()
        log.info("Navigated to Tasks home page")
        tasksPage.tasks_newrecord()
        log.info("Navigated to New tasks page")
        tasksPage.tasks_fillrecord_jsonkeys(testdata)
        tasksPage.save_tasks()
        tasksPage.confirm_task_created(testdata)
        log.info("Created New task")
        tasksPage.select_kanban(testdata["Kanban_Option"])
        tasksPage.verify_record_presence_inkanban(testdata["Subject"])
        log.info("Verified the task present in kanban view")
        edit_testdata = data["Edit New Task"]
        tasksPage.tasks_editrecord_jsonkeys(edit_testdata)
        tasksPage.save_tasks()
        log.info("Edited the task")
        tasksPage.verify_record_presence_inkanban(edit_testdata["Subject"])
        log.info("Verified the changed reflected in kanban view")