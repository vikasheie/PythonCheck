import time

from pageObjects.login_page import LoginPage
from pageObjects.organizations_page import OrganizationPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.organization_locators import OrganizationLocators


class TestSprint6Organizations(BaseClass):


    def test_sprint_CGT_23454(self):

        '''https://jiraprod.acml.com/browse/CGT-23454
        To Verify Removal of  Last Activity Dates/Last Meeting Notes  fields from Organization records '''

        log = customLogger()
        jsonfilename="sprint9_CGT_23454.json"
        data = self.getJsonData(jsonfilename)
        testdata = data["Institutional Investor"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        jsonkeys=loginPage.json_list_filter(list(data.keys()))
        for i in testdata["Record_Types"]:
            orgPage=OrganizationPage(self.driver,log)
            orgPage.organization_home()
            log.info("Navigated to Organization home page")
            orgPage.organization_newrecord(i)
            log.info("Navigated to Organization new record page: "+i)
            assert False==orgPage.waitForElementDisplay(OrganizationLocators.last_activity_date,timeout=1)
            assert False == orgPage.waitForElementDisplay(OrganizationLocators.last_activity_type, timeout=0.2)
            assert False == orgPage.waitForElementDisplay(OrganizationLocators.last_meeting_note, timeout=0.2)
            assert False == orgPage.waitForElementDisplay(OrganizationLocators.last_meeting_note_date, timeout=0.2)
            log.info("Verified Last activity date,type,meeting notes,meeting dates values are not present in: " + i)
            assert orgPage.elementClick(OrganizationLocators.cancelrecord)

    def test_sprint_CGT_23480(self):

        '''https://jiraprod.acml.com/browse/CGT-23480
        To Verify Updated Org Type/Sub-Type '''

        log = customLogger()
        jsonfilename="sprint6_CGT_23480.json"
        data = self.getJsonData(jsonfilename)
        testdata = data["Institutional Investor"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        jsonkeys=loginPage.json_list_filter(list(data.keys()))
        for i in testdata["Record_Types"]:
            orgPage=OrganizationPage(self.driver,log)
            orgPage.organization_home()
            log.info("Navigated to Organization home page")
            orgPage.organization_newrecord(i)
            log.info("Navigated to Organization new record page: "+i)
            type_list=orgPage.get_listdropdown_values(OrganizationLocators.type)
            print(type_list)
            for j in type_list:
                if j!="--None--":
                    orgPage.listtypedropdown(OrganizationLocators.type, j)
                    time.sleep(0.5)
                    sub_type_list = orgPage.get_listdropdown_values(OrganizationLocators.subtype)
                    print(j)
                    print(sub_type_list)
            orgPage.elementClick(OrganizationLocators.cancelrecord)