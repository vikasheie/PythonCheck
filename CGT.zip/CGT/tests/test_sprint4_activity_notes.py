import time

from pageObjects.login_page import LoginPage
from pageObjects.activity_notes_page import ActivityNotesPage
from pageObjects.organizations_page import OrganizationPage
from pageObjects.contacts_page import ContactPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.activity_notes_locators import ActivityNotesLocators


class TestSprint4ActivityNotes(BaseClass):



    def test_sprint4_CGT_22427(self):

        '''https://jiraprod.acml.com/browse/CGT-22427
        To Verify Meeting Note Audit'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22427.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created New Activity Notes")
        edit_testdata = data["Edit New Activity"]
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit_testdata)
        activitynotesPage.save_activity_notes()
        log.info("Edited the activity notes")
        activity_history_values=activitynotesPage.activity_notes_history("Title")
        print(activity_history_values)
        assert activity_history_values[0]==testdata["Title"]
        assert activity_history_values[1] == edit_testdata["Title"]
        log.info("Validated the original and new value")

    def test_sprint4_CGT_22428(self):

        '''https://jiraprod.acml.com/browse/CGT-22428
        To Verify Meeting Note mandatory Fields (Contacts & Organizations)'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22428.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_click_activity_notes()
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.contact_missing_error)
        log.info("Verified the contact missing error")
        activitynotesPage.remove_added_values(ActivityNotesLocators.organization_attended_remove)
        edit_testdata = data["Edit New Activity"]
        activitynotesPage.organization_contact_edit(edit_testdata)
        activitynotesPage.save_click_activity_notes()
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.organization_missing_error)
        log.info("Verified the organization missing error")
        activitynotesPage.remove_added_values(ActivityNotesLocators.organization_attended_remove)
        activitynotesPage.remove_added_values(ActivityNotesLocators.contacts_attended_remove)
        activitynotesPage.save_click_activity_notes()
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.organization_missing_error)
        activitynotesPage.waitForElementDisplay(ActivityNotesLocators.contact_missing_error)

    def test_sprint4_CGT_22467(self):

        '''https://jiraprod.acml.com/browse/CGT-22467
        To Verify Meeting Note to Multiple Contacts'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22467.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes with multiple contact")
        contact_list=activitynotesPage.getElementList(ActivityNotesLocators.multiple_contact)
        verification_list=[]
        for i in contact_list:
            verification_list.append(i.text)
        assert testdata["Contacts_Attended"]==verification_list
        for i in range(0,len(verification_list)):
            activitynotesPage.delete_record_inrightpanel(ActivityNotesLocators.contacts_attended_delete_dropdwown)
            time.sleep(1)
        edit_testdata = data["Edit New Activity"]
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit_testdata)
        time.sleep(2)
        assert False == activitynotesPage.waitForElementDisplay(ActivityNotesLocators.edit_contacts_attended_remove,timeout=3)

    def test_sprint4_CGT_22444(self):

        '''https://jiraprod.acml.com/browse/CGT-22444
        To verify Creation of Opportunity from Meeting Notes'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22444.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes")
        for i in testdata["Record_Types"]:
            activitynotesPage.select_opportunity(i)
            activitynotesPage.verify_opportunity_record_autopopulated()

    def test_sprint4_CGT_22447(self):

        '''https://jiraprod.acml.com/browse/CGT-22447
        To Verify Creation of Opportunity Quick Action (Contact & Organization)'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22447.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        organizationPage=OrganizationPage(self.driver,log)
        activitynotesPage = ActivityNotesPage(self.driver, log)
        for i in testdata["Organization_Record_Types"]:
            organizationPage.organization_home()
            new_testdata=data[i]
            organizationPage.organization_newrecord(i)
            organizationPage.organization_fillrecord_jsonkeys(new_testdata)
            organizationPage.save_organization()
            time.sleep(3)
            for i in testdata["Opportunity_Record_Types"]:
                activitynotesPage.select_opportunity(i)
                activitynotesPage.verify_organization_record_autopopulated()
        contactPage=ContactPage(self.driver,log)
        contact_testdata = data["External Contact"]
        contactPage.contact_home()
        contactPage.contact_newrecord(contact_testdata["Record_Type"])
        contactPage.contacts_fillrecord_jsonkeys(contact_testdata)
        contactPage.save_contacts()
        time.sleep(1)
        for i in testdata["Opportunity_Record_Types"]:
            activitynotesPage.select_opportunity(i)
            activitynotesPage.verify_organization_record_autopopulated()

    def test_sprint4_CGT_22488(self):

        '''https://jiraprod.acml.com/browse/CGT-22488
        To Verify Meeting Note to Multiple Orgs'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22488.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes with multiple organization")
        organization_list=activitynotesPage.getElementList(ActivityNotesLocators.multiple_organization)
        verification_list=[]
        for i in organization_list:
            verification_list.append(i.text)
        print(testdata["Organization_Attended"])
        print(verification_list)
        assert testdata["Organization_Attended"]==verification_list
        for i in range(0,len(verification_list)):
            activitynotesPage.delete_record_inrightpanel(ActivityNotesLocators.organization_attended_delete_dropdwown)
            time.sleep(1)
        edit_testdata = data["Edit New Activity"]
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit_testdata)
        time.sleep(2)
        assert False==activitynotesPage.waitForElementDisplay(ActivityNotesLocators.edit_organization_attended_remove,timeout=3)


    def test_sprint4_CGT_22495(self):

        '''https://jiraprod.acml.com/browse/CGT-22495
        To Verify Multiple Opportunities per Meeting Note'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22495.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes with multiple Opportunity")
        opportunity_list=activitynotesPage.getElementList(ActivityNotesLocators.multiple_opportunity)
        verification_list=[]
        for i in opportunity_list:
            verification_list.append(i.text)
        assert testdata["Opportunities_Discussed"]==verification_list
        for i in range(0,len(verification_list)):
            activitynotesPage.delete_record_inrightpanel(ActivityNotesLocators.opportunity_discussed_delete_dropdwown)
            time.sleep(1)
        time.sleep(2)
        edit_testdata = data["Edit New Activity"]
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit_testdata)
        time.sleep(2)
        assert False==activitynotesPage.waitForElementDisplay(ActivityNotesLocators.edit_opportunities_discussed_remove,timeout=3)
        activitynotesPage.save_activity_notes()
        time.sleep(2)
        edit1_testdata = data["Edit1 New Activity"]
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit1_testdata)
        assert activitynotesPage.waitForElementDisplay(ActivityNotesLocators.edit_opportunities_discussed_remove, timeout=3)

    def test_sprint4_CGT_22498(self):

        '''https://jiraprod.acml.com/browse/CGT-22498
        To Verify Adding Non-Salesforce User to Meeting'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22498.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes with multiple Employee")
        employee_list=activitynotesPage.getElementList(ActivityNotesLocators.multiple_employee)
        verification_list=[]
        for i in employee_list:
            verification_list.append(i.text)
        assert testdata["Employees_Attended"]==verification_list
        for i in range(0,len(verification_list)):
            activitynotesPage.delete_record_inrightpanel(ActivityNotesLocators.employees_attended_delete_dropdwown)
            time.sleep(1)
        time.sleep(2)
        edit_testdata = data["Edit New Activity"]
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit_testdata)
        time.sleep(2)
        assert False==activitynotesPage.waitForElementDisplay(ActivityNotesLocators.edit_employees_attended_remove,timeout=3)
        activitynotesPage.save_activity_notes()
        time.sleep(2)
        edit1_testdata = data["Edit1 New Activity"]
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit1_testdata)
        assert activitynotesPage.waitForElementDisplay(ActivityNotesLocators.edit_employees_attended_remove, timeout=3)

    def test_sprint4_CGT_22496(self):

        '''https://jiraprod.acml.com/browse/CGT-22496
        To Verify Product to Meeting Note Connection (and sentiment)'''

        log = customLogger()
        jsonfilename="sprint4_CGT_22496.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["New Activity"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        activitynotesPage=ActivityNotesPage(self.driver,log)
        activitynotesPage.activity_notes_home()
        log.info("Navigated to Activity Notes home page")
        activitynotesPage.activity_notes_newrecord()
        log.info("Navigated to New Activity Notes page")
        activitynotesPage.activity_notes_fillrecord_jsonkeys(testdata)
        activitynotesPage.save_activity_notes()
        log.info("Created new Activity notes with multiple Product")
        employee_list=activitynotesPage.getElementList(ActivityNotesLocators.multiple_product)
        verification_list=[]
        for i in employee_list:
            verification_list.append(i.text)
        assert testdata["Topics_Product_Discussed"]==verification_list
        for i in range(0,len(verification_list)):
            activitynotesPage.delete_record_inrightpanel(ActivityNotesLocators.topics_product_discussed_delete_dropdwown)
            time.sleep(1)
        time.sleep(2)
        edit_testdata = data["Edit New Activity"]
        activitynotesPage.activity_notes_editrecord_jsonkeys(edit_testdata)
        time.sleep(2)
        assert False==activitynotesPage.waitForElementDisplay(ActivityNotesLocators.edit_topics_product_discussed_remove,timeout=3)
