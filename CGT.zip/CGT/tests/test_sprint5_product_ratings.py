from pageObjects.login_page import LoginPage
from pageObjects.product_ratings_page import ProductRatingsPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.product_ratings_locators import ProductRatingsLocators


class TestSprint5ProductRatings(BaseClass):


    def test_sprint4_CGT_23003(self):

        '''https://jiraprod.acml.com/browse/CGT-23003
        To Verify Updated Product Ratings fields'''

        log = customLogger()
        jsonfilename="sprint5_CGT_23003.json"
        data = self.getJsonData(jsonfilename)
        testdata=data["Platform Availability Rating"]
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        jsonkeys=loginPage.json_list_filter(list(data.keys()))
        for i in jsonkeys:
            testdata = data[i]
            productratingPage=ProductRatingsPage(self.driver,log)
            productratingPage.prod_ratings_home()
            log.info("Navigated to Products ratings home page")
            productratingPage.prod_ratings_newrecord(i)
            assert testdata["Status_Values"]==productratingPage.get_buttondropdown_values(ProductRatingsLocators.status)
            productratingPage.prod_ratings_fillrecord_jsonkeys(testdata)
            productratingPage.save_product_rating()
            edit_testdata=data["Edit "+i]
            productratingPage.prod_ratings_editrecord_jsonkeys(edit_testdata)
            productratingPage.save_product_rating()
            testdata.update(edit_testdata)
            productratingPage.prod_ratings_verify_jsonkeys(testdata)
