import time

from pageObjects.login_page import LoginPage
from pageObjects.campaigns_page import CampaignPage
from utilities.BaseClass import BaseClass
from utilities.custom_logger import customLogger
from locators.campaigns_locators import CampaignsLocators

class TestSprint5Campaigns(BaseClass):

    def test_sprint5_CGT_22869(self):

        '''https://jiraprod.acml.com/browse/CGT-22869
        To Verify Cloned Campaign'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22869.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        campaignPage=CampaignPage(self.driver,log)
        for i in list(data.keys()):
            testdata=data[i]
            campaignPage.campaign_home()
            log.info("Navigated to Campaigns home page")
            campaignPage.campaign_newrecord(i)
            log.info("Navigated to new Campaigns page: "+i)
            campaignPage.campaign_fillrecord_jsonkeys(testdata)
            campaignPage.save_campaigns()
            log.info("Created new campaign: "+i)
            campaignPage.clone_campaign()
            log.info("Cloned the created campaign: "+i)
            campaignPage.campaign_verifyrecord_jsonkeys(testdata)
            log.info("Verified the cloned data for campaign: " + i)

    def test_sprint5_CGT_22871(self):

        '''https://jiraprod.acml.com/browse/CGT-22871
        To Verify Campaign to Product Relationship'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22871.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        campaignPage=CampaignPage(self.driver,log)
        for i in list(data.keys()):
            testdata=data[i]
            campaignPage.campaign_home()
            log.info("Navigated to Campaigns home page")
            campaignPage.campaign_newrecord(i)
            log.info("Navigated to new Campaigns page: "+i)
            campaignPage.campaign_fillrecord_jsonkeys(testdata)
            campaignPage.save_campaigns()
            log.info("Created new campaign: "+i)
            campaignPage.validate_product_campaign_linkage(testdata["Campaign_Name"])
            log.info("Verified Campaign to Product Relationship for: "+i)


    def test_sprint5_CGT_23032(self):

        '''https://jiraprod.acml.com/browse/CGT-23032
        To Verify Campaign Budget'''

        log = customLogger()
        jsonfilename="sprint5_CGT_23032.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        campaignPage=CampaignPage(self.driver,log)
        for i in list(data.keys()):
            testdata=data[i]
            campaignPage.campaign_home()
            log.info("Navigated to Campaigns home page")
            campaignPage.campaign_newrecord(i)
            log.info("Navigated to new Campaigns page: "+i)
            campaignPage.campaign_fillrecord_jsonkeys(testdata)
            campaignPage.validate_budget_fields()
            log.info("Validated Budget fields presence before saving record")
            campaignPage.save_campaigns()
            log.info("Created new campaign: "+i)
            campaignPage.validate_budget_fields()
            log.info("Validated Budget fields after before saving record")

    def test_sprint5_CGT_22873(self):

        '''https://jiraprod.acml.com/browse/CGT-22873
        To Verify Campaign Status'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22873.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        campaignPage=CampaignPage(self.driver,log)
        testdata = data["Marketing Event/Webinar Campaign"]
        campaignPage.campaign_home()
        log.info("Navigated to Campaigns home page")
        campaignPage.campaign_newrecord(testdata["Record_Type"])
        log.info("Navigated to new Campaigns page: " + testdata["Record_Type"])
        campaignPage.campaign_fillrecord_jsonkeys(testdata)
        log.info("Validated Budget fields presence before saving record")
        campaignPage.save_campaigns()
        log.info("Created new campaign: " + testdata["Record_Type"])
        campaignPage.add_and_save_campaign_member()
        campaignPage.verify_campaign_member_added()
        log.info("Added campaign member to the campaign")
        edit_testdata=data["Edit Marketing Event/Webinar Campaign"]
        campaignPage.campaign_editrecord_jsonkeys(edit_testdata)
        campaignPage.save_campaigns()
        log.info("Removed the Active Flag")
        campaignPage.add_and_save_campaign_member(default_option=2)
        campaignPage.verify_campaign_member_error()
        log.info("Error displayed while adding member to inactive campaign")

    def test_sprint5_CGT_22872(self):

        '''https://jiraprod.acml.com/browse/CGT-22872
        TTo Verify Campaign Record Types'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22872.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        campaignPage=CampaignPage(self.driver,log)
        testdata = data["Marketing Event/Webinar Campaign"]
        campaignPage.campaign_home()
        log.info("Navigated to Campaigns home page")
        campaignPage.select_new()
        assert campaignPage.waitForElementDisplay(CampaignsLocators.marketingevent_record_text)
        assert campaignPage.waitForElementDisplay(CampaignsLocators.email_campaign_record_text)
        assert campaignPage.waitForElementDisplay(CampaignsLocators.sales_campaign_record_text)
        campaignPage.elementClick(CampaignsLocators.record_cancel)
        log.info("Validated the Record type text")
        for i in list(data.keys()):
            testdata=data[i]
            campaignPage.campaign_home()
            log.info("Navigated to Campaigns home page")
            campaignPage.campaign_newrecord(i)
            log.info("Navigated to new Campaigns page: "+i)
            campaignPage.campaign_fillrecord_jsonkeys(testdata)
            campaignPage.save_campaigns()
            log.info("Created new campaign: "+i)

    def test_sprint5_CGT_22875(self):

        '''https://jiraprod.acml.com/browse/CGT-22875
        To verify Add/Remove Campaign Members'''

        log = customLogger()
        jsonfilename="sprint5_CGT_22875.json"
        data = self.getJsonData(jsonfilename)
        loginPage = LoginPage(self.driver,log)
        loginPage.salesforce_login()
        log.info("Salesforce login is success")
        campaignPage=CampaignPage(self.driver,log)
        for i in list(data.keys()):
            testdata = data[i]
            campaignPage.campaign_home()
            log.info("Navigated to Campaigns home page")
            campaignPage.campaign_newrecord(i)
            log.info("Navigated to new Campaigns page: " + i)
            campaignPage.campaign_fillrecord_jsonkeys(testdata)
            campaignPage.save_campaigns()
            log.info("Created new campaign: " + i)
            campaignPage.add_and_save_campaign_member()
            campaignPage.verify_campaign_member_added()
            log.info("Added campaign member to the campaign")
            campaignPage.add_and_save_campaign_member(default_option=3,viewoption="view all")
            log.info("Added campaign member in a view all page")
            campaign_mem_count=campaignPage.get_count_of_campaign_members_added()
            assert str(2)==campaign_mem_count
            for i in range(0,int(campaign_mem_count)):
                campaignPage.delete_campaign_members()
            log.info("Deleted the Campaign members added")