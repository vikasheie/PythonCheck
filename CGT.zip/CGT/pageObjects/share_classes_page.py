from pageObjects.base_page import BasePage
from locators.share_classes_locators import ShareClassesLocators





class ShareClassesPage(BasePage):


    def share_classes_home(self):

        assert self.javascriptClick(ShareClassesLocators.share_classes_tab)
        assert self.waitForPresenceOfElement(ShareClassesLocators.share_classes_home)

    def share_classes_newrecord(self):
        assert self.elementClick(ShareClassesLocators.share_classes_new)



    def save_share_classes(self):
        assert self.elementClick(ShareClassesLocators.save_button)
        assert self.waitForElementInvisible(ShareClassesLocators.save_and_new, timeout=3)
        assert self.waitForElementDisplay(ShareClassesLocators.share_class_record_page)



    def share_class_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Share_Class_Name" in keys:
            if data["Share_Class_Name"] == "None":
                data["Share_Class_Name"] = self.get_random_string(8)
            assert self.sendKeys(ShareClassesLocators.share_class_name, data["Share_Class_Name"])
        if "Asset_Class" in keys:
            assert self.sendKeysdownEnter(ShareClassesLocators.asset_class,data["Asset_Class"])
        if "Sub_Asset_Class" in keys:
            assert self.sendKeysdownEnter(ShareClassesLocators.sub_asset_class,data["Sub_Asset_Class"])
        if "Strategy" in keys:
            assert self.sendKeysdownEnter(ShareClassesLocators.strategy,data["Strategy"])
        if "Product" in keys:
            assert self.sendKeysdownEnter(ShareClassesLocators.product,data["Product"])
        if "Platform_Suite" in keys:
            assert self.sendKeysdownEnter(ShareClassesLocators.platform_suite,data["Platform_Suite"])
        if "Pooled_Fund" in keys:
            assert self.sendKeysdownEnter(ShareClassesLocators.pooled_fund,data["Pooled_Fund"])
        if "Income_Distribution_Type" in keys:
            assert self.spantypedropdown(ShareClassesLocators.income_distribution_type,data["Income_Distribution_Type"])
        if "Distribution_Frequency" in keys:
            assert self.spantypedropdown(ShareClassesLocators.distribution_frequency,data["Distribution_Frequency"])


