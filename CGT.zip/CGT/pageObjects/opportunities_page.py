import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.opportunities_locators import OpportunitiesLocators
from config import properties





class OpportunitiesPage(BasePage):


    def opportunities_home(self):
        try:
            assert self.javascriptClick(OpportunitiesLocators.opportunities_tab)
        except:
            assert self.javascriptClick(OpportunitiesLocators.more_tab)
            assert self.javascriptClick(OpportunitiesLocators.more_opportunities)
        assert self.waitForPresenceOfElement(OpportunitiesLocators.opportunities_home)

    def opportunity_newrecord(self,data):
        time.sleep(3)
        assert self.elementClick(OpportunitiesLocators.opportunities_new)
        dyanamic_record_locator=(By.XPATH,"(//div/span[text()='"+data+"'])[last()]")
        assert self.elementClick(dyanamic_record_locator)
        assert self.elementClick(OpportunitiesLocators.record_next)

    def opportunity_fillrecord(self,data):
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Opportunity_Name"]=self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.opportunity_name,data["Opportunity_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeysdownEnter(OpportunitiesLocators.organization_name,data["Organization_Name"])
            data["Organization_Name"]=self.getAttributeValue(OpportunitiesLocators.organization_name_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeysdownEnter(OpportunitiesLocators.opportunity_primary_contact,data["Opportunity_Primary_Contact"])
            data["Opportunity_Primary_Contact"]=self.getAttributeValue(OpportunitiesLocators.opportunity_primary_contact_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeys(OpportunitiesLocators.close_date,data["Close_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeys(OpportunitiesLocators.next_meeting_date,data["Next_Meeting_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.spantypedropdown(OpportunitiesLocators.stage,data["Stage"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.spantypedropdown(OpportunitiesLocators.opportunity_source,data["Opportunity_Source"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(OpportunitiesLocators.type,data["Type"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Amount"]=self.get_random_number(3)
            print(data["Amount"])
            assert self.sendKeys(OpportunitiesLocators.amount,data["Amount"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Probability"]=self.get_random_number(2)
            print(data["Probability"])
            assert self.sendKeys(OpportunitiesLocators.probability,data["Probability"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeysdownEnter(OpportunitiesLocators.product,data["Product"])
            data["Product"]=self.getAttributeValue(OpportunitiesLocators.product_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            data["Next_Step"]=self.get_random_string(5)
            assert self.sendKeys(OpportunitiesLocators.next_step,data["Next_Step"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Description"] = self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.description,data["Description"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeysdownEnter(OpportunitiesLocators.primary_campaign_source, data["Primary_Campaign_Source"])
            data["Primary_Campaign_Source"]=self.getAttributeValue(OpportunitiesLocators.primary_campaign_source_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Result_Reason"] = self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.result_reason,data["Result_Reason"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeysdownEnter(OpportunitiesLocators.winning_competitor, data["Winning_Competitor"])
            data["Winning_Competitor"]=self.getAttributeValue(OpportunitiesLocators.winning_competitor_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][1], data["Record_Type"][2]]:
            data["Fee"]=self.get_random_number(4)
            assert self.sendKeys(OpportunitiesLocators.fee,data["Fee"])
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            data["Amount_Retained"] = self.get_random_number(4)
            assert self.sendKeys(OpportunitiesLocators.amount_retained,data["Amount_Retained"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert self.spantypedropdown(OpportunitiesLocators.purpose,data["Purpose"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert self.sendKeysdownEnter(OpportunitiesLocators.platform,data["Platform"])
            data["Platform"]=self.getAttributeValue(OpportunitiesLocators.platform_getext)
        assert self.elementClick(OpportunitiesLocators.save_button)
        assert self.waitForElementInvisible(OpportunitiesLocators.save_and_new_button)
        assert self.waitForElementDisplay(OpportunitiesLocators.opportunity_record_page)

    def opportunity_editrecord(self,data):
        assert self.elementClick(OpportunitiesLocators.opportunity_edit)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Opportunity_Name"]=self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.opportunity_name,data["Opportunity_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.javascriptClick(OpportunitiesLocators.organization_name_clear)
            assert self.sendKeysdownEnter(OpportunitiesLocators.organization_name,data["Edit_Organization_Name"])
            data["Organization_Name"]=self.getAttributeValue(OpportunitiesLocators.organization_name_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.javascriptClick(OpportunitiesLocators.opportunity_primary_contact_clear)
            assert self.sendKeysdownEnter(OpportunitiesLocators.opportunity_primary_contact,data["Edit_Opportunity_Primary_Contact"])
            data["Opportunity_Primary_Contact"]=self.getAttributeValue(OpportunitiesLocators.opportunity_primary_contact_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeys(OpportunitiesLocators.close_date,data["Close_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeys(OpportunitiesLocators.next_meeting_date,data["Next_Meeting_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.spantypedropdown(OpportunitiesLocators.stage,data["Edit_Stage"])
            data["Stage"]=data["Edit_Stage"]
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.spantypedropdown(OpportunitiesLocators.opportunity_source,data["Edit_Opportunity_Source"])
            data["Opportunity_Source"]=data["Edit_Opportunity_Source"]
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(OpportunitiesLocators.type,data["Edit_Type"])
            data["Type"]=data["Edit_Type"]
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Amount"]=self.get_random_number(3)
            assert self.sendKeys(OpportunitiesLocators.amount,data["Amount"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Probability"]=self.get_random_number(2)
            print(data["Probability"])
            assert self.sendKeys(OpportunitiesLocators.probability,data["Probability"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.javascriptClick(OpportunitiesLocators.product_clear)
            assert self.sendKeysdownEnter(OpportunitiesLocators.product,data["Edit_Product"])
            data["Product"]=self.getAttributeValue(OpportunitiesLocators.product_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            data["Next_Step"]=self.get_random_string(5)
            assert self.sendKeys(OpportunitiesLocators.next_step,data["Next_Step"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Description"] = self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.description,data["Description"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.javascriptClick(OpportunitiesLocators.primary_campaign_source_clear)
            assert self.sendKeysdownEnter(OpportunitiesLocators.primary_campaign_source, data["Edit_Primary_Campaign_Source"])
            data["Primary_Campaign_Source"]=self.getAttributeValue(OpportunitiesLocators.primary_campaign_source_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Result_Reason"] = self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.result_reason,data["Result_Reason"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.javascriptClick(OpportunitiesLocators.winning_competitor_clear)
            assert self.sendKeysdownEnter(OpportunitiesLocators.winning_competitor, data["Edit_Winning_Competitor"])
            data["Winning_Competitor"]=self.getAttributeValue(OpportunitiesLocators.winning_competitor_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][1], data["Record_Type"][2]]:
            data["Fee"]=self.get_random_number(4)
            assert self.sendKeys(OpportunitiesLocators.fee,data["Fee"])
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            data["Amount_Retained"] = self.get_random_number(4)
            assert self.sendKeys(OpportunitiesLocators.amount_retained,data["Amount_Retained"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert self.spantypedropdown(OpportunitiesLocators.purpose,data["Edit_Purpose"])
            data["Purpose"]=data["Edit_Purpose"]
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert self.javascriptClick(OpportunitiesLocators.platform_clear)
            assert self.sendKeysdownEnter(OpportunitiesLocators.platform,data["Edit_Platform"])
            data["Platform"]=self.getAttributeValue(OpportunitiesLocators.platform_getext)
        assert self.elementClick(OpportunitiesLocators.save_button)
        assert self.waitForElementInvisible(OpportunitiesLocators.save_and_new_button)

    def opportunity_verifyrecord(self,data):
        assert self.elementClick(OpportunitiesLocators.details_tab)
        assert self.elementClick(OpportunitiesLocators.opportunity_edit_display)
        # if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
        #     assert data["Opportunity_Name"]==self.getAttributeValue(OpportunitiesLocators.opportunity_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Organization_Name"]==self.getAttributeValue(OpportunitiesLocators.organization_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Opportunity_Primary_Contact"]==self.getAttributeValue(OpportunitiesLocators.opportunity_primary_contact_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Close_Date"]==self.getAttributeValue(OpportunitiesLocators.close_date_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Next_Meeting_Date"]==self.getAttributeValue(OpportunitiesLocators.next_meeting_date_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Stage"]==self.getText(OpportunitiesLocators.stage_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Opportunity_Source"]==self.getText(OpportunitiesLocators.opportunity_source_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Type"]==self.getText(OpportunitiesLocators.type_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Amount"]="$"+data["Amount"]+".00"
            assert data["Amount"]==self.getAttributeValue(OpportunitiesLocators.amount_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Probability"]=data["Probability"]+"%"
            assert data["Probability"]==self.getAttributeValue(OpportunitiesLocators.probability_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Product"]==self.getAttributeValue(OpportunitiesLocators.product_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert data["Next_Step"]==self.getAttributeValue(OpportunitiesLocators.next_step_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Description"]==self.getAttributeValue(OpportunitiesLocators.description_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Primary_Campaign_Source"]==self.getAttributeValue(OpportunitiesLocators.primary_campaign_source_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Result_Reason"]==self.getAttributeValue(OpportunitiesLocators.result_reason_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Winning_Competitor"]==self.getAttributeValue(OpportunitiesLocators.winning_competitor_display)
        if data["One_Record_Type"] in [data["Record_Type"][1], data["Record_Type"][2]]:
            fees_value=str(self.getAttributeValue(OpportunitiesLocators.fee_display))
            new_value=fees_value.replace(",","")
            assert data["Fee"]==new_value
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            retained_amount=str(self.getAttributeValue(OpportunitiesLocators.amount_retained_display))
            new_retained_amount=retained_amount.replace(",","")
            assert data["Amount_Retained"]==new_retained_amount
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert data["Purpose"]==self.getText(OpportunitiesLocators.purpose_display)
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert data["Platform"]==self.getAttributeValue(OpportunitiesLocators.platform_display)
        assert self.elementClick(OpportunitiesLocators.edit_display_cancel)

    def opportunity_allrecord_create_verify(self,data):
        testdata = data["Advisor Agreement"]
        for i in testdata["Record_Type"]:
            testdata.update(data[i])
            testdata["One_Record_Type"] = i
            self.opportunities_home()
            self.log.info("Navigated to Opportunities tab")
            self.opportunity_newrecord(i)
            self.log.info("Navigated to Creation of new Opportunities record page :" + i)
            self.opportunity_fillrecord(testdata)
            self.log.info("Created new Opportunity Successfully")
            self.opportunity_verifyrecord(testdata)
            self.log.info("Verified the created Opportunity Successfully")
            edittestdata = testdata.copy()
            self.opportunity_editrecord(edittestdata)
            self.log.info("Edited the created Opportunity Successfully")
            self.opportunity_verifyrecord(edittestdata)
            self.log.info("Verified the Opportunity Successfully")

    def opportunity_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Opportunity_Name" in keys:
            if data["Opportunity_Name"]=="None":
                data["Opportunity_Name"]=self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.opportunity_name,data["Opportunity_Name"])
        if "Organization_Name" in keys:
            assert self.sendKeysdownEnter(OpportunitiesLocators.organization_name,data["Organization_Name"])
            data["Organization_Name"]=self.getAttributeValue(OpportunitiesLocators.organization_name_gettext)
        if "Opportunity_Primary_Contact" in keys:
            assert self.sendKeysdownEnter(OpportunitiesLocators.opportunity_primary_contact,data["Opportunity_Primary_Contact"])
            data["Opportunity_Primary_Contact"]=self.getAttributeValue(OpportunitiesLocators.opportunity_primary_contact_gettext)
        if "Close_Date" in keys:
            if data["Close_Date"] == "None":
                data["Close_Date"]=self.getTodayDate()
            assert self.sendKeys(OpportunitiesLocators.close_date,data["Close_Date"])
        if "Next_Meeting_Date" in keys:
            if data["Next_Meeting_Date"] == "None":
                data["Next_Meeting_Date"] = self.getTodayDate()
            assert self.sendKeys(OpportunitiesLocators.next_meeting_date,data["Next_Meeting_Date"])
        if "Stage" in keys:
            assert self.spantypedropdown(OpportunitiesLocators.stage,data["Stage"])
        if "Opportunity_Source" in keys:
            assert self.spantypedropdown(OpportunitiesLocators.opportunity_source,data["Opportunity_Source"])
        if "Type" in [data["Record_Type"][0]]:
            assert self.spantypedropdown(OpportunitiesLocators.type,data["Type"])
        if "Amount" in keys:
            if data["Amount"] == "None":
                data["Amount"]=self.get_random_number(3)
            assert self.sendKeys(OpportunitiesLocators.amount,data["Amount"])
        if "Probability" in keys:
            if data["Probability"] == "None":
                data["Probability"]=self.get_random_number(2)
            assert self.sendKeys(OpportunitiesLocators.probability,data["Probability"])
        if "Product" in keys:
            assert self.sendKeysdownEnter(OpportunitiesLocators.product,data["Product"])
            data["Product"]=self.getAttributeValue(OpportunitiesLocators.product_gettext)
        if "Next_Step" in keys:
            if data["Next_Step"] == "None":
                data["Next_Step"]=self.get_random_string(5)
            assert self.sendKeys(OpportunitiesLocators.next_step,data["Next_Step"])
        if "Description" in keys:
            if data["Description"] == "None":
                data["Description"] = self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.description,data["Description"])
        if "Primary_Campaign_Source" in keys:
            assert self.sendKeysdownEnter(OpportunitiesLocators.primary_campaign_source, data["Primary_Campaign_Source"])
            data["Primary_Campaign_Source"]=self.getAttributeValue(OpportunitiesLocators.primary_campaign_source_gettext)
        if "Result_Reason" in keys:
            if data["Result_Reason"] == "None":
                data["Result_Reason"] = self.get_random_string(8)
            assert self.sendKeys(OpportunitiesLocators.result_reason,data["Result_Reason"])
        if "Winning_Competitor" in keys:
            assert self.sendKeysdownEnter(OpportunitiesLocators.winning_competitor, data["Winning_Competitor"])
            data["Winning_Competitor"]=self.getAttributeValue(OpportunitiesLocators.winning_competitor_gettext)
        if "Fee" in keys:
            if data["Fee"] == "None":
                data["Fee"]=self.get_random_number(4)
            assert self.sendKeys(OpportunitiesLocators.fee,data["Fee"])
        if "Amount_Retained" in keys:
            if data["Amount_Retained"] == "None":
                data["Amount_Retained"] = self.get_random_number(4)
            assert self.sendKeys(OpportunitiesLocators.amount_retained,data["Amount_Retained"])
        if "Purpose" in keys:
            assert self.spantypedropdown(OpportunitiesLocators.purpose,data["Purpose"])
        if "Platform" in keys:
            assert self.sendKeysdownEnter(OpportunitiesLocators.platform,data["Platform"])
            data["Platform"]=self.getAttributeValue(OpportunitiesLocators.platform_getext)
        if "Win_Loss_Reason" in keys:
            assert self.multiselectdropdown(type="Win/Loss Reason",options=data["Win_Loss_Reason"])

    def save_opportunity(self):
        assert self.elementClick(OpportunitiesLocators.save_button)
        assert self.waitForElementInvisible(OpportunitiesLocators.save_and_new_button)
        assert self.waitForElementDisplay(OpportunitiesLocators.opportunity_record_page)

    def validate_opportunity_name(self,testdata):
        Opportunity_name = None
        if testdata["Record_Type"] == "Advisor Agreement":
            Opportunity_name = testdata["Opportunity_Primary_Contact"] + " " + testdata["Organization_Name"] + " " + \
                               testdata["Product"] + " " + testdata["Amount"]
        elif testdata["Record_Type"] == "Platform Placement":
            Opportunity_name = testdata["Organization_Name"] + " " + testdata["Product"] + " " + testdata[
                "Purpose"]
        else:
            Opportunity_name = testdata["Organization_Name"] + " " + testdata["Product"] + " " + testdata["Amount"]
        print(Opportunity_name)
        print(self.getText(OpportunitiesLocators.get_opportunity_name))
        assert Opportunity_name == self.getText(OpportunitiesLocators.get_opportunity_name)