import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.contacts_locators import ContactLocators
from config import properties





class ContactPage(BasePage):


    def contact_home(self):

        assert self.javascriptClick(ContactLocators.contacts_tab)
        assert self.waitForPresenceOfElement(ContactLocators.contacts_home)

    def contact_newrecord(self,data):
        time.sleep(3)
        assert self.elementClick(ContactLocators.contacts_new)
        dyanamic_record_locator=(By.XPATH,"(//div/span[text()='"+data+"'])[last()]")
        assert self.elementClick(dyanamic_record_locator)
        assert self.elementClick(ContactLocators.record_next)
        time.sleep(1)

    def contacts_fillrecord(self,data):
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Preferred_Name"]=self.get_random_string(8)
            assert self.sendKeys(ContactLocators.preferred_name,data["Preferred_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.spantypedropdown(ContactLocators.salutation,data["Salutation"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["First_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.first_name,data["First_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Middle_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.middle_name,data["Middle_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Last_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.last_name,data["Last_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Suffix"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.suffix,data["Suffix"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeysdownEnter(ContactLocators.organisation_name,data["Organization_Name"])
            data["Organization_Name"] = self.getAttributeValue(ContactLocators.organization_name_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["Title"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.title,data["Title"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["Linkedin"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.linkedIn,data["Linkedin"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.status,data["Status"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert self.spantypedropdown(ContactLocators.type,data["Type"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert self.spantypedropdown(ContactLocators.sub_type,data["Subtype"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Email"] = self.get_random_string(8)+data["Email"]
            assert self.sendKeys(ContactLocators.email,data["Email"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.phone,data["Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["Mobile"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.mobile,data["Mobile"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.other_phone,data["Other_Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Assistant"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.assistant,data["Assistant"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Assistant_Email"] = self.get_random_string(8)+data["Assistant_Email"]
            assert self.sendKeys(ContactLocators.assistant_email,data["Assistant_Email"])
        if data["One_Record_Type"] in [data["Record_Type"][0],]:
            data["Asst_Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.asst_phone,data["Asst_Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.language,data["Language"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            data["Description"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.description,data["Description"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_Street"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_street,data["Mailing_Street"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_Street"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_street,data["Other_Street"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_City"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_city,data["Mailing_City"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_State"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_state,data["Mailing_State"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_City"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_city,data["Other_City"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_State"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_state,data["Other_State"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_Zip"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.mailing_zip,data["Mailing_Zip"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_Country"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_country,data["Mailing_Country"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_Zip"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.other_zip,data["Other_Zip"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_Country"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_country,data["Other_Country"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.region, data["Region"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.level_of_influence, data["Level_Of_Influence"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.javascriptClick(ContactLocators.centre_of_influence)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.javascriptClick(ContactLocators.key_contact)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.javascriptClick(ContactLocators.top_producer)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.javascriptClick(ContactLocators.dual_registered)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.strength_of_relationship, data["Strength_Of_Relationship"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.relationship_pricing_contract, data["Relationship_Pricing_Contact"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_rm_contact_date,data["Last_RM_Contact_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_rc_ontact_date,data["Last_RC_Contact_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_activity_date,data["Last_Activity_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_irs_contact_date,data["Last_IRS_Contact_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_srg_contact_date,data["Last_SRG_Contact_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Last_Activity_Type"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.last_activity_type,data["Last_Activity_Type"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["RP_Group"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.rp_group,data["RP_Group"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["CRD_Code"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.crd_code,data["CRD_Code"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["DST_ID"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.dst_id,data["DST_ID"])
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            data["Employee_ID"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.employee_id,data["Employee_ID"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert self.spantypedropdown(ContactLocators.inactive_reason, data["Inactive_Reason"])
        assert self.elementClick(ContactLocators.save_button)
        assert self.waitForElementInvisible(ContactLocators.save_and_new_button)
        assert self.waitForPresenceOfElement(ContactLocators.contacts_home)

    def contacts_editrecord(self,data):
        assert self.elementClick(ContactLocators.contacts_edit)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Preferred_Name"]=self.get_random_string(8)
            assert self.sendKeys(ContactLocators.preferred_name,data["Preferred_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.spantypedropdown(ContactLocators.salutation,data["Edit_Salutation"])
            data["Salutation"]=data["Edit_Salutation"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["First_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.first_name,data["First_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Middle_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.middle_name,data["Middle_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Last_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.last_name,data["Last_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Suffix"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.suffix,data["Suffix"])
        # if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
        #     assert self.sendKeysdownEnter(ContactLocators.organisation_name,data["Organization_Name"])
        #     data["Organization_Name"] = self.getText(ContactLocators.organization_name_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["Title"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.title,data["Title"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["Linkedin"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.linkedIn,data["Linkedin"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.status,data["Edit_Status"])
            data["Status"]=data["Edit_Status"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert self.spantypedropdown(ContactLocators.type,data["Edit_Type"])
            data["Type"]=data["Edit_Type"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert self.spantypedropdown(ContactLocators.sub_type,data["Edit_Subtype"])
            data["Subtype"]=data["Edit_Subtype"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Email"] = self.get_random_string(8)+data["Email"]
            assert self.sendKeys(ContactLocators.email,data["Email"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.phone,data["Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["Mobile"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.mobile,data["Mobile"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.other_phone,data["Other_Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Assistant"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.assistant,data["Assistant"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Assistant_Email"] = self.get_random_string(8)+data["Assistant_Email"]
            assert self.sendKeys(ContactLocators.assistant_email,data["Assistant_Email"])
        if data["One_Record_Type"] in [data["Record_Type"][0],]:
            data["Asst_Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.asst_phone,data["Asst_Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.language,data["Edit_Language"])
            data["Language"]=data["Edit_Language"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            data["Description"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.description,data["Description"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_Street"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_street,data["Mailing_Street"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_Street"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_street,data["Other_Street"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_City"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_city,data["Mailing_City"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_State"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_state,data["Mailing_State"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_City"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_city,data["Other_City"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_State"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_state,data["Other_State"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_Zip"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.mailing_zip,data["Mailing_Zip"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            data["Mailing_Country"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_country,data["Mailing_Country"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_Zip"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.other_zip,data["Other_Zip"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Other_Country"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_country,data["Other_Country"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.region, data["Edit_Region"])
            data["Region"]=data["Edit_Region"]
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.level_of_influence, data["Edit_Level_Of_Influence"])
            data["Level_Of_Influence"]=data["Edit_Level_Of_Influence"]
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.javascriptClick(ContactLocators.centre_of_influence)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.javascriptClick(ContactLocators.key_contact)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.javascriptClick(ContactLocators.top_producer)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.javascriptClick(ContactLocators.dual_registered)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.strength_of_relationship, data["Edit_Strength_Of_Relationship"])
            data["Strength_Of_Relationship"]=data["Edit_Strength_Of_Relationship"]
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ContactLocators.relationship_pricing_contract, data["Edit_Relationship_Pricing_Contact"])
            data["Relationship_Pricing_Contact"]=data["Edit_Relationship_Pricing_Contact"]
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_rm_contact_date,data["Last_RM_Contact_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_rc_ontact_date,data["Last_RC_Contact_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_activity_date,data["Last_Activity_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_irs_contact_date,data["Last_IRS_Contact_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ContactLocators.last_srg_contact_date,data["Last_SRG_Contact_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Last_Activity_Type"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.last_activity_type,data["Last_Activity_Type"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["RP_Group"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.rp_group,data["RP_Group"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["CRD_Code"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.crd_code,data["CRD_Code"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["DST_ID"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.dst_id,data["DST_ID"])
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            data["Employee_ID"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.employee_id,data["Employee_ID"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert self.spantypedropdown(ContactLocators.inactive_reason, data["Inactive_Reason"])
        assert self.elementClick(ContactLocators.save_button)
        assert self.waitForElementInvisible(ContactLocators.save_and_new_button)

    def contacts_verification(self,data):
        assert self.elementClick(ContactLocators.details_tab)
        assert self.elementClick(ContactLocators.name_edit_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Preferred_Name"]==self.getAttributeValue(ContactLocators.preferred_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Salutation"]==self.getText(ContactLocators.salutation_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["First_Name"]==self.getAttributeValue(ContactLocators.first_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Middle_Name"]==self.getAttributeValue(ContactLocators.middle_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Last_Name"]==self.getAttributeValue(ContactLocators.last_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Suffix"]==self.getAttributeValue(ContactLocators.suffix_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Organization_Name"]==self.getAttributeValue(ContactLocators.organisation_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            assert data["Title"]==self.getAttributeValue(ContactLocators.title_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            assert data["Linkedin"]==self.getAttributeValue(ContactLocators.linkedIn_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Status"]==self.getText(ContactLocators.status_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert data["Type"]==self.getText(ContactLocators.type_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert data["Subtype"]==self.getText(ContactLocators.sub_type_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Email"]==self.getAttributeValue(ContactLocators.email_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            assert data["Phone"]==self.getAttributeValue(ContactLocators.phone_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            assert data["Mobile"]==self.getAttributeValue(ContactLocators.mobile_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Other_Phone"]==self.getAttributeValue(ContactLocators.other_phone_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Assistant"]==self.getAttributeValue(ContactLocators.assistant_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Assistant_Email"]==self.getAttributeValue(ContactLocators.assistant_email_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],]:
            assert data["Asst_Phone"]==self.getAttributeValue(ContactLocators.asst_phone_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Language"]==self.getText(ContactLocators.language_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert data["Description"]==self.getAttributeValue(ContactLocators.description_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Mailing_Street"]==self.getAttributeValue(ContactLocators.mailing_street_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Other_Street"]==self.getAttributeValue(ContactLocators.other_street_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Mailing_City"]==self.getAttributeValue(ContactLocators.mailing_city_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Mailing_State"]==self.getAttributeValue(ContactLocators.mailing_state_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Other_City"]==self.getAttributeValue(ContactLocators.other_city_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Other_State"]==self.getAttributeValue(ContactLocators.other_state_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Mailing_Zip"]==self.getAttributeValue(ContactLocators.mailing_zip_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2]]:
            assert data["Mailing_Country"]==self.getAttributeValue(ContactLocators.mailing_country_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Other_Zip"]==self.getAttributeValue(ContactLocators.other_zip_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Other_Country"]==self.getAttributeValue(ContactLocators.other_country_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Region"]==self.getText(ContactLocators.region_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Level_Of_Influence"]==self.getText(ContactLocators.level_of_influence_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Strength_Of_Relationship"]==self.getText(ContactLocators.strength_of_relationship_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Relationship_Pricing_Contact"]==self.getText(ContactLocators.relationship_pricing_contract_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Last_RM_Contact_Date"]==self.getAttributeValue(ContactLocators.last_rm_contact_date_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Last_RC_Contact_Date"]==self.getAttributeValue(ContactLocators.last_rc_contact_date_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Last_Activity_Date"]==self.getAttributeValue(ContactLocators.last_activity_date_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Last_IRS_Contact_Date"]==self.getAttributeValue(ContactLocators.last_irs_contact_date_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Last_SRG_Contact_Date"]==self.getAttributeValue(ContactLocators.last_srg_contact_date_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["Last_Activity_Type"]==self.getAttributeValue(ContactLocators.last_activity_type_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["RP_Group"]==self.getAttributeValue(ContactLocators.rp_group_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["CRD_Code"]==self.getAttributeValue(ContactLocators.crd_code_display)
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert data["DST_ID"]==self.getAttributeValue(ContactLocators.dst_id_display)
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            assert data["Employee_ID"]==self.getAttributeValue(ContactLocators.employee_id_display)
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert data["Inactive_Reason"]==self.getText(ContactLocators.inactive_reason_display)
        assert self.elementClick(ContactLocators.edit_display_cancel)

    def contacts_allrecord_create_verify(self,data):
        testdata = data["External Contact"]
        for i in testdata["Record_Type"]:
            testdata.update(data[i])
            testdata["One_Record_Type"]=i
            self.contact_home()
            self.log.info("Navigated to Contacts tab")
            self.contact_newrecord(i)
            self.log.info("Navigated to Creation of new contact record page :"+ i)
            self.contacts_fillrecord(testdata)
            self.log.info("Record created succesfully")
            if testdata["One_Record_Type"]=="External Contact":
                self.preference_center_validation()
                self.preference_center_communication_save(testdata)
                self.preference_center_communication_validate(testdata)
                self.preference_center_subscription_create()
                self.preference_center_subscription_validate()
                self.preference_center_productpreference_create()
                self.preference_center_productpreference_validate()
                self.preference_center_productliterature_create()
                self.preference_center_productliterature_validate()
                self.log.info("Created and saved preference center datas")
                self.asset_flow_validation(testdata)
            self.contacts_verification(testdata)
            self.log.info("Record verified succesfully")
            edittestdata = testdata.copy()
            self.contacts_editrecord(edittestdata)
            self.log.info("Edited the records Successfully")
            self.contacts_verification(edittestdata)
            self.log.info("Record verified succesfully")

    def preference_center_validation(self):
        assert self.waitForElementDisplay(ContactLocators.preference_center)
        assert self.javascriptClick(ContactLocators.preference_center)
        assert self.waitForElementDisplay(ContactLocators.communication_preference)
        assert self.waitForElementDisplay(ContactLocators.subscription)
        assert self.waitForElementDisplay(ContactLocators.product_preferences)
        assert self.waitForElementDisplay(ContactLocators.product_literature_content)

    def preference_center_communication_save(self,data):
        assert self.spantypedropdown(ContactLocators.preferred_communication_channel,data["Preferred_Communication_Channel"])
        assert self.javascriptClick(ContactLocators.unsubscribed)
        assert self.javascriptClick(ContactLocators.bounce_flag)
        assert self.javascriptClick(ContactLocators.opt_out_of_marketing)
        assert self.elementClick(ContactLocators.preference_save_button)
        assert self.elementClick(ContactLocators.preference_confirm_changes)
        assert self.waitForElementInvisible(ContactLocators.preference_cancel_button)

    def preference_center_communication_validate(self,data):
        assert self.javascriptClick(ContactLocators.preference_center)
        time.sleep(2)
        assert data["Preferred_Communication_Channel"]==self.getText(ContactLocators.preferred_communication_channel)
        assert self.isElementSelected(ContactLocators.unsubscribed)
        assert self.isElementSelected(ContactLocators.bounce_flag)
        assert self.isElementSelected(ContactLocators.opt_out_of_marketing)
        assert self.elementClick(ContactLocators.preference_cancel_button)

    def preference_center_subscription_create(self):
        time.sleep(2)
        assert self.elementClick(ContactLocators.preference_center)
        assert self.waitForElementDisplay(ContactLocators.subscription_2nd_tab)
        assert self.elementClick(ContactLocators.subscription)
        assert self.elementClick(ContactLocators.subscription_add_all)
        assert self.waitForElementDisplay(ContactLocators.subscription_remove_all)
        assert self.javascriptClick(ContactLocators.preference_save_button)
        assert self.javascriptClick(ContactLocators.preference_confirm_changes)
        assert self.waitForElementInvisible(ContactLocators.preference_cancel_button)


    def preference_center_subscription_validate(self):
        assert self.javascriptClick(ContactLocators.preference_center)
        assert self.elementClick(ContactLocators.subscription)
        assert self.isElementSelected(ContactLocators.ab_advisor_institute)
        assert self.isElementSelected(ContactLocators.investment_insights)
        assert self.isElementSelected(ContactLocators.product_updates)
        assert self.isElementSelected(ContactLocators.market_insights)
        assert self.isElementSelected(ContactLocators.inside_ab)
        assert self.javascriptClick(ContactLocators.preference_cancel_button)

    def preference_center_productliterature_create(self):
        time.sleep(2)
        assert self.javascriptClick(ContactLocators.preference_center)
        assert self.elementClick(ContactLocators.product_literature_content)
        assert self.elementClick(ContactLocators.product_literature_content_addall)
        assert self.waitForElementDisplay(ContactLocators.product_literature_content_removeall)
        assert self.javascriptClick(ContactLocators.preference_save_button)
        assert self.javascriptClick(ContactLocators.preference_confirm_changes)
        assert self.waitForElementInvisible(ContactLocators.preference_cancel_button)

    def preference_center_productliterature_validate(self):
        assert self.javascriptClick(ContactLocators.preference_center)
        assert self.elementClick(ContactLocators.product_literature_content)
        assert self.isElementSelected(ContactLocators.fact_sheet)
        assert self.isElementSelected(ContactLocators.tax_guidelines)
        assert self.isElementSelected(ContactLocators.divident_distribution)
        assert self.isElementSelected(ContactLocators.scorecards)
        assert self.isElementSelected(ContactLocators.product_brief)
        assert self.isElementSelected(ContactLocators.commentaries)
        assert self.isElementSelected(ContactLocators.pm_announcements)
        assert self.javascriptClick(ContactLocators.preference_cancel_button)

    def preference_center_productpreference_create(self,option="None",data="Test"):
        time.sleep(2)
        assert self.javascriptClick(ContactLocators.preference_center)
        assert self.elementClick(ContactLocators.product_preferences)
        time.sleep(1)
        if option=="filter":
            assert self.sendKeys(ContactLocators.product_preferences_filter,data)
            time.sleep(0.5)
        assert self.javascriptClick(ContactLocators.product_preferences_checkbox)
        time.sleep(1)
        assert self.javascriptClick(ContactLocators.preference_save_button)
        assert self.javascriptClick(ContactLocators.preference_confirm_changes)
        assert self.waitForElementInvisible(ContactLocators.preference_cancel_button)

    def preference_center_productpreference_validate(self,type='select',option="None",data="Test"):
        time.sleep(3)
        assert self.javascriptClick(ContactLocators.preference_center)
        assert self.elementClick(ContactLocators.product_preferences)
        if option=="filter":
            assert self.sendKeys(ContactLocators.product_preferences_filter,data)
            time.sleep(0.5)
        if type=='select':
            assert self.waitForElementDisplay(ContactLocators.product_preferences_checkbox_selected)
        elif type=='unselect':
            assert False==self.isElementSelected(ContactLocators.product_preferences_checkbox_selected)
        assert self.javascriptClick(ContactLocators.preference_cancel_button)

    def asset_flow_validation(self,data):
        assert self.elementClick(ContactLocators.assets_flow)
        for i in data["Assets"]:
            self.asset_values(i)
        for j in data["Flows"]:
            self.flow_values(j)

    def contacts_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Preferred_Name" in keys:
            if data["Preferred_Name"] == "None":
                data["Preferred_Name"]=self.get_random_string(8)
            assert self.sendKeys(ContactLocators.preferred_name,data["Preferred_Name"])
        if "Salutation" in keys:
            assert self.spantypedropdown(ContactLocators.salutation,data["Salutation"])
        if "First_Name" in keys:
            if data["First_Name"] == "None":
                data["First_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.first_name,data["First_Name"])
        if "Middle_Name" in keys:
            if data["Middle_Name"] == "None":
                data["Middle_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.middle_name,data["Middle_Name"])
        if "Last_Name" in keys:
            if data["Last_Name"] == "None":
                data["Last_Name"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.last_name,data["Last_Name"])
        if "Suffix" in keys:
            if data["Suffix"] == "None":
                data["Suffix"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.suffix,data["Suffix"])
        if "Organization_Name" in keys:
            assert self.sendKeysdownEnter(ContactLocators.organisation_name,data["Organization_Name"])
            data["Organization_Name"] = self.getAttributeValue(ContactLocators.organization_name_gettext)
        if "Title" in keys:
            if data["Title"] == "None":
                data["Title"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.title,data["Title"])
        if "Linkedin" in keys:
            if data["Linkedin"] == "None":
                data["Linkedin"] = self.get_random_string(8)
            assert self.sendKeys(ContactLocators.linkedIn,data["Linkedin"])
        if "Status" in keys:
            assert self.spantypedropdown(ContactLocators.status,data["Status"])
        if "Type" in keys:
            assert self.spantypedropdown(ContactLocators.type,data["Type"])
        if "Subtype" in keys:
            assert self.spantypedropdown(ContactLocators.sub_type,data["Subtype"])
        if "Email" in keys:
            if data["Email"] == "None":
                data["Email"] = self.get_random_string(8)+"@testing.com"
            assert self.sendKeys(ContactLocators.email,data["Email"])
        if "Phone" in keys:
            if data["Phone"] == "None":
                data["Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.phone,data["Phone"])
        if "Mobile" in keys:
            if data["Mobile"] == "None":
                data["Mobile"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.mobile,data["Mobile"])
        if "Other_Phone" in keys:
            if data["Other_Phone"] == "None":
                data["Other_Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.other_phone,data["Other_Phone"])
        if "Assistant" in keys:
            if data["Assistant"] == "None":
                data["Assistant"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.assistant,data["Assistant"])
        if "Assistant_Email" in keys:
            if data["Assistant_Email"] == "None":
                data["Assistant_Email"] = self.get_random_string(8)+"@testing.com"
            assert self.sendKeys(ContactLocators.assistant_email,data["Assistant_Email"])
        if "Asst_Phone" in keys:
            if data["Asst_Phone"] == "None":
                data["Asst_Phone"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.asst_phone,data["Asst_Phone"])
        if "Language" in keys:
            assert self.spantypedropdown(ContactLocators.language,data["Language"])
        if "Description" in keys:
            if data["Description"] == "None":
                data["Description"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.description,data["Description"])
        if "Mailing_Street" in keys:
            if data["Mailing_Street"] == "None":
                data["Mailing_Street"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_street,data["Mailing_Street"])
        if "Other_Street" in keys:
            if data["Other_Street"] == "None":
                data["Other_Street"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_street,data["Other_Street"])
        if "Mailing_City" in keys:
            if data["Mailing_City"] == "None":
                data["Mailing_City"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_city,data["Mailing_City"])
        if "Mailing_State" in keys:
            if data["Mailing_State"] == "None":
                data["Mailing_State"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_state,data["Mailing_State"])
        if "Other_City" in keys:
            if data["Other_City"] == "None":
                data["Other_City"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_city,data["Other_City"])
        if "Other_State" in keys:
            if data["Other_State"] == "None":
                data["Other_State"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_state,data["Other_State"])
        if "Mailing_Zip" in keys:
            if data["Mailing_Zip"] == "None":
                data["Mailing_Zip"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.mailing_zip,data["Mailing_Zip"])
        if "Mailing_Country" in keys:
            if data["Mailing_Country"] == "None":
                data["Mailing_Country"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.mailing_country,data["Mailing_Country"])
        if "Other_Zip" in keys:
            if data["Other_Zip"] == "None":
                data["Other_Zip"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.other_zip,data["Other_Zip"])
        if "Other_Country" in keys:
            if data["Other_Country"] == "None":
                data["Other_Country"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.other_country,data["Other_Country"])
        if "Region" in keys:
            assert self.spantypedropdown(ContactLocators.region, data["Region"])
        if "Level_Of_Influence" in keys:
            assert self.spantypedropdown(ContactLocators.level_of_influence, data["Level_Of_Influence"])
        if "Centre_Of_Influence" in keys:
            assert self.javascriptClick(ContactLocators.centre_of_influence)
        if "Key_Contact" in keys:
            assert self.javascriptClick(ContactLocators.key_contact)
        if "Top_Producer" in keys:
            assert self.javascriptClick(ContactLocators.top_producer)
        if "Dual_Registered" in keys:
            assert self.javascriptClick(ContactLocators.dual_registered)
        if "Strength_Of_Relationship" in keys:
            assert self.spantypedropdown(ContactLocators.strength_of_relationship, data["Strength_Of_Relationship"])
        if "Relationship_Pricing_Contact" in keys:
            assert self.spantypedropdown(ContactLocators.relationship_pricing_contract, data["Relationship_Pricing_Contact"])
        if "Last_RM_Contact_Date" in keys:
            if data["Last_RM_Contact_Date"] == "None":
                data["Last_RM_Contact_Date"]=self.getTodayDate()
            assert self.sendKeys(ContactLocators.last_rm_contact_date,data["Last_RM_Contact_Date"])
        if "Last_RC_Contact_Date" in keys:
            if data["Last_RC_Contact_Date"] == "None":
                data["Last_RC_Contact_Date"] = self.getTodayDate()
            assert self.sendKeys(ContactLocators.last_rc_ontact_date,data["Last_RC_Contact_Date"])
        if "Last_Activity_Date" in keys:
            if data["Last_Activity_Date"] == "None":
                data["Last_Activity_Date"] = self.getTodayDate()
            assert self.sendKeys(ContactLocators.last_activity_date,data["Last_Activity_Date"])
        if "Last_IRS_Contact_Date" in keys:
            if data["Last_IRS_Contact_Date"] == "None":
                data["Last_IRS_Contact_Date"] = self.getTodayDate()
            assert self.sendKeys(ContactLocators.last_irs_contact_date,data["Last_IRS_Contact_Date"])
        if "Last_SRG_Contact_Date" in keys:
            if data["Last_SRG_Contact_Date"] == "None":
                data["Last_SRG_Contact_Date"] = self.getTodayDate()
            assert self.sendKeys(ContactLocators.last_srg_contact_date,data["Last_SRG_Contact_Date"])
        if "Last_Activity_Type" in keys:
            if data["Last_Activity_Type"] == "None":
                data["Last_Activity_Type"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.last_activity_type,data["Last_Activity_Type"])
        if "RP_Group" in keys:
            if data["RP_Group"] == "None":
                data["RP_Group"] = self.get_random_string(10)
            assert self.sendKeys(ContactLocators.rp_group,data["RP_Group"])
        if "CRD_Code" in keys:
            if data["CRD_Code"] == "None":
                data["CRD_Code"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.crd_code,data["CRD_Code"])
        if "DST_ID" in keys:
            if data["DST_ID"] == "None":
                data["DST_ID"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.dst_id,data["DST_ID"])
        if "Employee_ID" in keys:
            if data["Employee_ID"] =="None":
                data["Employee_ID"] = self.get_random_number(10)
            assert self.sendKeys(ContactLocators.employee_id,data["Employee_ID"])
        if "Inactive_Reason" in keys:
            assert self.spantypedropdown(ContactLocators.inactive_reason, data["Inactive_Reason"])
        if "Focus_Advisor" in keys:
            assert self.multiselectmove(option="Focus Advisor",listvalues=data["Focus_Advisor"])

    def save_contacts(self):
        assert self.elementClick(ContactLocators.save_button)
        assert self.waitForElementInvisible(ContactLocators.save_and_new_button)
        assert self.waitForPresenceOfElement(ContactLocators.contact_record_page)

    def contact_product_preference_history(self,option):
        dyanamiclocator=(By.XPATH,"(//b[text()='Contact Product Preference History']/../../..//tbody/tr/th)["+str(option)+"]")
        self.waitForElementDisplay(dyanamiclocator)
        text=self.getText(dyanamiclocator)
        return text

    def contact_marketing_preference_history(self, option):
        dyanamiclocator = (By.XPATH, "(//b[text()='Contact Marketing Preference History']/../../..//tbody/tr/th["+str(option)+"])")
        list_value=self.getElementList(dyanamiclocator)
        list=[]
        for i in list_value:
            list.append(i.text)
        return list
