import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.organization_locators import OrganizationLocators
from config import properties





class OrganizationPage(BasePage):


    def organization_home(self):

        assert self.javascriptClick(OrganizationLocators.organization_tab)
        assert self.waitForPresenceOfElement(OrganizationLocators.organization_home)

    def organization_newrecord(self,data):
        time.sleep(3)
        assert self.elementClick(OrganizationLocators.organization_new)
        dyanamic_record_locator=(By.XPATH,"(//div/span[text()='"+data+"'])[last()]")
        assert self.elementClick(dyanamic_record_locator)
        assert self.elementClick(OrganizationLocators.record_next)

    def organization_fillrecord(self,data):
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            assert self.sendKeysdownEnterList(OrganizationLocators.parent_organization, data["Parent_Organization"])
            data["Parent_Organization"] = self.getText(OrganizationLocators.parent_organization_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5]]:
            assert self.listtypedropdown(OrganizationLocators.status,data["Status"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert self.listtypedropdown(OrganizationLocators.organization_hierarchy, data["Organization_Hierarchy_Level"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert self.listtypedropdown(OrganizationLocators.type, data["Type"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert self.listtypedropdown(OrganizationLocators.subtype, data["Subtype"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Website"] = self.get_random_string(6) + data["Website"]
            assert self.sendKeys(OrganizationLocators.website, data["Website"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5]]:
            data["General_Email"] = self.get_random_string(6) + data["General_Email"]
            assert self.sendKeys(OrganizationLocators.general_email, data["General_Email"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Phone"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.phone, data["Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5]]:
            data["Alternate_Phone"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.alternate_phone, data["Alternate_Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Fax"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.fax, data["Fax"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_Street"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.visiting_street, data["Visiting_Street"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_Street"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.correspondance_street, data["Correspondence_Street"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_City"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.visiting_city, data["Visiting_City"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_State"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.visiting_state, data["Visiting_State"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_City"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.correspondance_city, data["Correspondence_City"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_State"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.correspondance_state, data["Correspondence_State"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_Zip"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.visiting_zip, data["Visiting_Zip"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_Country"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.visiting_country, data["Visiting_Country"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_Zip"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.correspondance_zip, data["Correspondence_Zip"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_Country"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.correspondance_country, data["Correspondence_Country"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            data["Description"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.description, data["Description"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            assert self.sendKeysdownEnterList(OrganizationLocators.organization_name, data["Organization_Name"])
            data["Organization_Name"]=self.getText(OrganizationLocators.organization_name_gettext)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            data["Known_as_Name"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.known_as_name, data["Known_as_Name"])

        if data["One_Record_Type"] in [data["Record_Type"][2], data["Record_Type"][7]]:
            assert self.listtypedropdown(OrganizationLocators.market_influence,data["Market_Influence"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(OrganizationLocators.network_status,data["Network_Status"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(OrganizationLocators.intermediary_type,data["Intermediary_Type"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            data["DST_ID"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.dst_id, data["DST_ID"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            data["CRD_Number"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.crd_number, data["CRD_Number"])
        assert self.elementClick(OrganizationLocators.saverecord)
        assert self.waitForElementDisplay(OrganizationLocators.organization_record_page)

    def organization_editrecord(self,data):

        assert self.elementClick(OrganizationLocators.organization_edit)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2],data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
              data["Known_as_Name"] = self.get_random_string(6) + data["Known_as_Name"]
              assert self.sendKeys(OrganizationLocators.known_as_name, data["Known_as_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5]]:
            assert self.listtypedropdown(OrganizationLocators.status,data["Edit_Status"])
            data["Status"]=data["Edit_Status"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert self.listtypedropdown(OrganizationLocators.organization_hierarchy, data["Edit_Organization_Hierarchy_Level"])
            data["Organization_Hierarchy_Level"]=data["Edit_Organization_Hierarchy_Level"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2],
                                       data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert self.listtypedropdown(OrganizationLocators.type, data["Edit_Type"])
            data["Type"]=data["Edit_Type"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Website"] = self.get_random_string(6) + data["Website"]
            assert self.sendKeys(OrganizationLocators.website, data["Website"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert self.listtypedropdown(OrganizationLocators.subtype, data["Edit_Subtype"])
            data["Subtype"]=data["Edit_Subtype"]
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5]]:
            data["General_Email"] = self.get_random_string(6) + data["General_Email"]
            assert self.sendKeys(OrganizationLocators.general_email, data["General_Email"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Phone"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.phone, data["Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5]]:
            data["Alternate_Phone"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.alternate_phone, data["Alternate_Phone"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Fax"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.fax, data["Fax"] )
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_Street"] = self.get_random_string(6) + data["Visiting_Street"]
            assert self.sendKeys(OrganizationLocators.visiting_street, data["Visiting_Street"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_Street"] = self.get_random_string(6) + data["Correspondence_Street"]
            assert self.sendKeys(OrganizationLocators.correspondance_street, data["Correspondence_Street"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_City"] = self.get_random_string(6) + data["Visiting_City"]
            assert self.sendKeys(OrganizationLocators.visiting_city, data["Visiting_City"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_State"] = self.get_random_string(6) + data["Visiting_State"]
            assert self.sendKeys(OrganizationLocators.visiting_state, data["Visiting_State"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_City"] = self.get_random_string(6) + data["Correspondence_City"]
            assert self.sendKeys(OrganizationLocators.correspondance_city, data["Correspondence_City"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_State"] = self.get_random_string(6) + data["Correspondence_State"]
            assert self.sendKeys(OrganizationLocators.correspondance_state, data["Correspondence_State"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_Zip"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.visiting_zip, data["Visiting_Zip"] )
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Visiting_Country"] = self.get_random_string(6) + data["Visiting_Country"]
            assert self.sendKeys(OrganizationLocators.visiting_country,data["Visiting_Country"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_Zip"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.correspondance_zip, data["Correspondence_Zip"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4],
                                       data["Record_Type"][5], data["Record_Type"][6]]:
            data["Correspondence_Country"] = self.get_random_string(6) + data["Correspondence_Country"]
            assert self.sendKeys(OrganizationLocators.correspondance_country, data["Correspondence_Country"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2],
                                       data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6],
                                       data["Record_Type"][7]]:
            data["Description"] = self.get_random_string(6) + data["Description"]
            assert self.sendKeys(OrganizationLocators.description, data["Description"])
        if data["One_Record_Type"] in [data["Record_Type"][2], data["Record_Type"][7]]:
            assert self.listtypedropdown(OrganizationLocators.market_influence, data["Edit_Market_Influence"])
            data["Market_Influence"]=data["Edit_Market_Influence"]
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(OrganizationLocators.network_status, data["Edit_Network_Status"])
            data["Network_Status"]=data["Edit_Network_Status"]
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(OrganizationLocators.intermediary_type, data["Edit_Intermediary_Type"])
            data["Intermediary_Type"]=data["Edit_Intermediary_Type"]
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            data["DST_ID"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.dst_id, data["DST_ID"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            data["CRD_Number"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.crd_number, data["CRD_Number"])
        assert self.elementClick(OrganizationLocators.saverecord)
        time.sleep(2)
        assert self.waitForElementInvisible(OrganizationLocators.save_and_new)


    def organization_verification(self,data):
        assert self.elementClick(OrganizationLocators.organisation_edit_display)
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5]]:
            assert data["Status"]==self.getText(OrganizationLocators.status_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert data["Organization_Hierarchy_Level"]==self.getText(OrganizationLocators.organization_hierarchy_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert data["Type"]==self.getText(OrganizationLocators.type_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert data["Subtype"]==self.getText(OrganizationLocators.subtype_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Website"]==self.getAttributeValue(OrganizationLocators.website_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5]]:
            assert data["General_Email"]==self.getAttributeValue(OrganizationLocators.general_email_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Phone"]==self.getAttributeValue(OrganizationLocators.phone_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5]]:
            assert data["Alternate_Phone"]==self.getAttributeValue(OrganizationLocators.alternate_phone_display )
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert  data["Fax"]==self.getAttributeValue(OrganizationLocators.fax_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Visiting_Street"]==self.getAttributeValue(OrganizationLocators.visiting_street_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Correspondence_Street"]==self.getAttributeValue(OrganizationLocators.correspondance_street_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Visiting_City"]==self.getAttributeValue(OrganizationLocators.visiting_city_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Visiting_State"]==self.getAttributeValue(OrganizationLocators.visiting_state_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Correspondence_City"]==self.getAttributeValue(OrganizationLocators.correspondance_city_dispaly)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert  data["Correspondence_State"]==self.getAttributeValue(OrganizationLocators.correspondance_state_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert  data["Visiting_Zip"]==self.getAttributeValue(OrganizationLocators.visiting_zip_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Visiting_Country"]==self.getAttributeValue(OrganizationLocators.visiting_country_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Correspondence_Zip"]==self.getAttributeValue(OrganizationLocators.correspondance_zip_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6]]:
            assert data["Correspondence_Country"]==self.getAttributeValue(OrganizationLocators.correspondance_country_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            assert  data["Description"]==self.getAttributeValue(OrganizationLocators.description_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            assert data["Organization_Name"]==self.getAttributeValue(OrganizationLocators.organization_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][7]]:
            assert data["Known_as_Name"]==self.getAttributeValue(OrganizationLocators.known_as_name_display)
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            assert  data["Parent_Organization"]==self.getAttributeValue(OrganizationLocators.parent_organization_display)
        if data["One_Record_Type"] in [data["Record_Type"][2], data["Record_Type"][7]]:
            assert data["Market_Influence"]==self.getText(OrganizationLocators.market_influence_display)
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert data["Network_Status"]==self.getText(OrganizationLocators.network_status_display)
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert data["Intermediary_Type"]==self.getText(OrganizationLocators.intermediary_type_display)
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert data["DST_ID"]==self.getAttributeValue(OrganizationLocators.dst_id_display)
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert data["CRD_Number"]==self.getAttributeValue(OrganizationLocators.crd_number_display)
        assert self.elementClick(OrganizationLocators.edit_display_cancel)
        # assert self.waitForElementDisplay(OrganizationLocators.organization_record_page)

    def organization_allrecords_create_verify(self,data):
        testdata = data["Institutional Investor"]
        for i in testdata["Record_Type"]:
            testdata.update(data[i])
            testdata["One_Record_Type"]=i
            self.organization_home()
            self.log.info("Navigated to Organization tab")
            self.organization_newrecord(i)
            self.log.info("Navigated to Creation of new organization record page :"+ i)
            self.organization_fillrecord(testdata)
            self.log.info("Record created succesfully")
            self.organization_verification(testdata)
            self.log.info("Successfully Verified the Record created")
            edittestdata = testdata.copy()
            self.organization_editrecord(edittestdata)
            self.log.info("Edited the records Successfully")
            self.organization_verification(edittestdata)
            self.log.info("Successfully Verified the Record edited")
            if testdata["One_Record_Type"] in ["Intermediary","Consultant","Institutional Investor","Insurance Investor"]:
                self.asset_flow_validation(testdata)
                self.log.info("Validated Assets and Flow Values")

    def asset_flow_validation(self,data):
        assert self.elementClick(OrganizationLocators.assets_flow)
        for i in data["Assets"]:
            self.asset_values(i)
        for j in data["Flows"]:
            self.flow_values(j)

    def organization_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Parent_Organization" in keys:
            assert self.sendKeysdownEnterList(OrganizationLocators.parent_organization, data["Parent_Organization"])
            data["Parent_Organization"] = self.getText(OrganizationLocators.parent_organization_gettext)
        if "Status" in keys:
            assert self.listtypedropdown(OrganizationLocators.status,data["Status"])
        if "Organization_Hierarchy_Level" in keys:
            assert self.listtypedropdown(OrganizationLocators.organization_hierarchy, data["Organization_Hierarchy_Level"])
        if "Type" in keys:
            assert self.listtypedropdown(OrganizationLocators.type, data["Type"])
        if "Subtype" in keys:
            assert self.listtypedropdown(OrganizationLocators.subtype, data["Subtype"])
        if "Website" in keys:
            if data["Website"] == "None":
                data["Website"] = self.get_random_string(6) +"@testing.com"
            assert self.sendKeys(OrganizationLocators.website, data["Website"])
        if "General_Email" in keys:
            if data["General_Email"] == "None":
                data["General_Email"] = self.get_random_string(6) + "@testing.com"
            assert self.sendKeys(OrganizationLocators.general_email, data["General_Email"])
        if "Phone" in keys:
            if data["Phone"] == "None":
                data["Phone"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.phone, data["Phone"])
        if "Alternate_Phone" in keys:
            if data["Alternate_Phone"] == "None":
                data["Alternate_Phone"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.alternate_phone, data["Alternate_Phone"])
        if "Fax" in keys:
            if data["Fax"] == "None":
                data["Fax"] = self.get_random_number(10)
            assert self.sendKeys(OrganizationLocators.fax, data["Fax"])
        if "Visiting_Street" in keys:
            if data["Visiting_Street"] == "None":
                data["Visiting_Street"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.visiting_street, data["Visiting_Street"])
        if "Correspondence_Street" in keys:
            if data["Correspondence_Street"] == "None":
                data["Correspondence_Street"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.correspondance_street, data["Correspondence_Street"])
        if "Visiting_City" in keys:
            if data["Visiting_City"] == "None":
                data["Visiting_City"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.visiting_city, data["Visiting_City"])
        if "Visiting_State" in keys:
            if data["Visiting_State"] == "None":
                data["Visiting_State"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.visiting_state, data["Visiting_State"])
        if "Correspondence_City" in keys:
            if data["Correspondence_City"] == "None":
                data["Correspondence_City"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.correspondance_city, data["Correspondence_City"])
        if "Correspondence_State" in keys:
            if data["Correspondence_State"] == "None":
                data["Correspondence_State"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.correspondance_state, data["Correspondence_State"])
        if "Visiting_Zip" in keys:
            if data["Visiting_Zip"] == "None":
                data["Visiting_Zip"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.visiting_zip, data["Visiting_Zip"])
        if "Visiting_Country" in keys:
            if data["Visiting_Country"] == "None":
                data["Visiting_Country"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.visiting_country, data["Visiting_Country"])
        if "Correspondence_Zip" in keys:
            if data["Correspondence_Zip"] == "None":
                data["Correspondence_Zip"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.correspondance_zip, data["Correspondence_Zip"])
        if "Correspondence_Country" in keys:
            if data["Correspondence_Country"] == "None":
                data["Correspondence_Country"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.correspondance_country, data["Correspondence_Country"])
        if "Description" in keys:
            if data["Description"] == "None":
                data["Description"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.description, data["Description"])
        if "Organization_Name" in keys:
            assert self.sendKeysdownEnterList(OrganizationLocators.organization_name, data["Organization_Name"])
            data["Organization_Name"]=self.getText(OrganizationLocators.organization_name_gettext)
        if "Known_as_Name" in keys:
            if data["Known_as_Name"]=="None":
                data["Known_as_Name"] = self.get_random_string(8)
            assert self.sendKeys(OrganizationLocators.known_as_name, data["Known_as_Name"])
        if "Market_Influence" in keys:
            assert self.listtypedropdown(OrganizationLocators.market_influence,data["Market_Influence"])
        if "Network_Status" in keys:
            assert self.listtypedropdown(OrganizationLocators.network_status,data["Network_Status"])
        if "Intermediary_Type" in keys:
            assert self.listtypedropdown(OrganizationLocators.intermediary_type,data["Intermediary_Type"])
        if "DST_ID" in keys:
            if data["DST_ID"] == "None":
                data["DST_ID"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.dst_id, data["DST_ID"])
        if "CRD_Number" in keys:
            if data["CRD_Number"] == "None":
                data["CRD_Number"] = self.get_random_number(6)
            assert self.sendKeys(OrganizationLocators.crd_number, data["CRD_Number"])

    def save_organization(self):
        assert self.elementClick(OrganizationLocators.saverecord)
        assert self.waitForElementDisplay(OrganizationLocators.organization_record_page)