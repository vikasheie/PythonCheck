import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.platform_availability_locators import PlatformAvailabilityLocators
from config import properties





class PlatformAvailabilityPage(BasePage):


    def platform_availability_home(self):
        assert self.javascriptClick(PlatformAvailabilityLocators.platform_availability_tab)
        assert self.waitForPresenceOfElement(PlatformAvailabilityLocators.platform_availability_home,timeout=40)

    def filter_record_check(self,data):
        assert self.spantypedropdown(PlatformAvailabilityLocators.organizations_filter,data["Organization"])
        time.sleep(4)
        column_count=(By.XPATH,"//th[text()='"+data["Organization"]+"']")
        assert self.waitForElementDisplay(column_count,timeout=20)
        l=self.getElementList(PlatformAvailabilityLocators.header_count)
        count=0
        for i in l:
            value=i.text
            if value==data["Platform"]:
                break
            count=count+1
        print(count)
        row_match=(By.XPATH,"//table/tbody/tr/td['"+data["Product"]+"']/../td["+str(count)+"]")
        assert self.elementClick(row_match)
        assert data["Rating"]==self.getText(PlatformAvailabilityLocators.rating)
        assert data["SMA_Fee"]+"%" == self.getAttributeValue(PlatformAvailabilityLocators.sma_fee)
        assert "$"+data["SMA_Minimum"]+".00" == self.getAttributeValue(PlatformAvailabilityLocators.sma_minimum)
        assert data["Product"] == self.getAttributeValue(PlatformAvailabilityLocators.product)
        assert data["Platform"] == self.getAttributeValue(PlatformAvailabilityLocators.platform)
        assert data["Organization"] == self.getAttributeValue(PlatformAvailabilityLocators.organization)
        assert self.elementClick(PlatformAvailabilityLocators.edit_platform_availability_cancel)

    def platform_availability_validation(self,data):
        testdata = data["Platform_Availability"]
        testdata.update(data["Platform Availability Rating"])
        self.platform_availability_home()
        self.filter_record_check(testdata)

