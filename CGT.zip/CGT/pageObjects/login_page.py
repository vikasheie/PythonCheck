import time

import pyotp
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.login_locators import LoginLocators
from config import properties





class LoginPage(BasePage):


    def salesforce_login(self):

        assert self.sendKeys(LoginLocators.username,properties.username)
        assert self.sendKeys(LoginLocators.password, properties.password)
        assert self.elementClick(LoginLocators.loginbutton)
        # time.sleep(120)
        try:
            # totp=pyotp.TOTP(properties.key)
            # print(totp.now())
            # assert self.sendKeys(LoginLocators.otp, totp.now())
            # assert self.elementClick(LoginLocators.otp_verify)
            assert self.waitForElementDisplay(LoginLocators.registermobile,timeout=3)
            assert self.elementClick(LoginLocators.registermobile)
        except:
            pass
        assert self.waitForPresenceOfElement(LoginLocators.homepage)




