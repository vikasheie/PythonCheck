import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.platforms_locators import PlatformsLocators
from config import properties





class PlatformsPage(BasePage):


    def platforms_home(self):

        assert self.javascriptClick(PlatformsLocators.platforms_tab)
        assert self.waitForPresenceOfElement(PlatformsLocators.platforms_home)

    def platform_newrecord(self):
        assert self.elementClick(PlatformsLocators.platforms_new)
        time.sleep(1)


    def platform_fillrecord(self,data):
        data["Platform_Name"]=self.get_random_string(5)
        assert self.sendKeys(PlatformsLocators.platform_name,data["Platform_Name"])
        data["Platform"]=data["Platform_Name"]
        assert self.spantypedropdown(PlatformsLocators.platform_type, data["Platform_Type"])
        assert self.spantypedropdown(PlatformsLocators.unsolicited, data["Unsolicited"])
        assert self.spantypedropdown(PlatformsLocators.status, data["Status"])
        data["Description"] = self.get_random_string(5)
        assert self.sendKeys(PlatformsLocators.description, data["Description"])
        assert self.sendKeysdownEnter(PlatformsLocators.parent_organization, data["Parent_Organization"])
        data["Organization"]=self.getAttributeValue(PlatformsLocators.parent_organization)
        assert self.elementClick(PlatformsLocators.save)
        assert self.waitForElementDisplay(PlatformsLocators.platform_record_page)

    def platform_create_record(self,data):
        testdata = data["Platforms"]
        self.platforms_home()
        self.log.info("Navigated to Platforms tab")
        self.platform_newrecord()
        self.log.info("Navigated to Creation of new Platforms record page ")
        self.platform_fillrecord(testdata)
        self.log.info("Created Platforms Successfully")





