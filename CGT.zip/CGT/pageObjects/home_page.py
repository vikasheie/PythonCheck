from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.home_locatots import HomeLocators





class HomePage(BasePage):


    def search_google(self,text):

        self.sendkeys_enter(HomeLocators.google_search,text)
        assert self.isElementPresent(HomeLocators.searchresult)
        print(type(HomeLocators.searchresult))


    def google_images(self):
        assert self.elementClick(HomeLocators.images)
        assert self.isElementPresent(HomeLocators.imageverification)

    def signin(self):
        assert self.elementClick(HomeLocators.sigin)
        assert self.isElementPresent(HomeLocators.email)





