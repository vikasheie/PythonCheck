import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.product_ratings_locators import ProductRatingsLocators
from config import properties





class ProductRatingsPage(BasePage):


    def prod_ratings_home(self):

        assert self.javascriptClick(ProductRatingsLocators.prod_rating_tab)
        assert self.waitForPresenceOfElement(ProductRatingsLocators.prod_rating_home)

    def prod_ratings_newrecord(self,data):
        time.sleep(3)
        assert self.elementClick(ProductRatingsLocators.prod_rating_new)
        dyanamic_record_locator=(By.XPATH,"(//div/span[text()='"+data+"'])[last()]")
        assert self.elementClick(dyanamic_record_locator)
        assert self.elementClick(ProductRatingsLocators.record_next)

    def prod_ratings_fillrecord(self,data):
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1]]:
            assert self.sendKeysdownEnter(ProductRatingsLocators.organization,data["Organization"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeysdownEnter(ProductRatingsLocators.platform,data["Platform"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeysdownEnter(ProductRatingsLocators.product,data["Product"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1]]:
            assert self.spantypedropdown(ProductRatingsLocators.status,data["Status"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1]]:
            assert self.sendKeys(ProductRatingsLocators.rating_last_confirmed_on,data["Rating_Last_Confirmed_On"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["SMA_Fee"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.sma_fee,data["SMA_Fee"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["SMA_Minimum"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.sma_minimum,data["SMA_Minimum"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ProductRatingsLocators.model_delivery,data["Model_Delivery"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ProductRatingsLocators.rating,data["Rating"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1]]:
            assert self.sendKeys(ProductRatingsLocators.rating_date,data["Rating_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1]]:
            data["Original_Product_Rating"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.original_product_rating,data["Original_Product_Rating"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1]]:
            data["Comments"]=self.get_random_string(8)
            assert self.sendKeys(ProductRatingsLocators.comments,data["Comments"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1]]:
            data["Prior_Rating"]=self.get_random_number(3)
            assert self.sendKeys(ProductRatingsLocators.prior_rating,data["Prior_Rating"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1]]:
            assert self.sendKeys(ProductRatingsLocators.prior_rating_date_change,data["Prior_Rating_Date_Change"])
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            assert self.sendKeysdownEnter(ProductRatingsLocators.strategy,data["Strategy"])
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            assert self.spantypedropdown(ProductRatingsLocators.product_rating,data["Product_Rating"])
        self.save_product_rating()

    def prod_ratings_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Organization" in keys:
            assert self.sendKeysdownEnter(ProductRatingsLocators.organization,data["Organization"])
            data["Organization"]=self.getAttributeValue(ProductRatingsLocators.organization_gettext)
        if "Platform" in keys:
            assert self.sendKeysdownEnter(ProductRatingsLocators.platform,data["Platform"])
            data["Platform"] = self.getAttributeValue(ProductRatingsLocators.platform_gettext)
        if "Product" in keys:
            assert self.sendKeysdownEnter(ProductRatingsLocators.product,data["Product"])
            data["Product"] = self.getAttributeValue(ProductRatingsLocators.product_gettext)
        if "Status" in keys:
            assert self.spantypedropdown(ProductRatingsLocators.status,data["Status"])
        if "Rating_Last_Confirmed_On" in keys:
            if data["Rating_Last_Confirmed_On"]=="None":
                data["Rating_Last_Confirmed_On"]=self.getTodayDate()
            assert self.sendKeys(ProductRatingsLocators.rating_last_confirmed_on,data["Rating_Last_Confirmed_On"])
        if "Rating_Last_Confirmed_By" in keys:
            assert self.sendKeysdownEnter(ProductRatingsLocators.rating_last_confirmed_by,data["Rating_Last_Confirmed_By"])
        if "SMA_Fee" in keys:
            if data["SMA_Fee"]=="None":
                data["SMA_Fee"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.sma_fee,data["SMA_Fee"])
        if "SMA_Minimum" in keys:
            if data["SMA_Minimum"]=="None":
                data["SMA_Minimum"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.sma_minimum,data["SMA_Minimum"])
        if "Model_Delivery" in keys:
            assert self.spantypedropdown(ProductRatingsLocators.model_delivery,data["Model_Delivery"])
        if "Rating" in keys:
            assert self.spantypedropdown(ProductRatingsLocators.rating,data["Rating"])
        if "Rating_Date" in keys:
            if data["Rating_Date"]=="None":
                data["Rating_Date"] = self.getTodayDate()
            assert self.sendKeys(ProductRatingsLocators.rating_date,data["Rating_Date"])
        if "Original_Product_Rating" in keys:
            if data["Original_Product_Rating"]=="None":
                data["Original_Product_Rating"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.original_product_rating,data["Original_Product_Rating"])
        if "Comments" in keys:
            if data["Comments"]=="None":
                data["Comments"]=self.get_random_string(8)
            assert self.sendKeys(ProductRatingsLocators.comments,data["Comments"])
        if "Prior_Rating" in keys:
            if data["Prior_Rating"]=="None":
                data["Prior_Rating"]=self.get_random_number(3)
            assert self.sendKeys(ProductRatingsLocators.prior_rating,data["Prior_Rating"])
        if "Prior_Rating_Date_Change" in keys:
            if data["Prior_Rating_Date_Change"]=="None":
                data["Prior_Rating_Date_Change"] = self.getTodayDate()
            assert self.sendKeys(ProductRatingsLocators.prior_rating_date_change,data["Prior_Rating_Date_Change"])
        if "Strategy" in keys:
            assert self.sendKeysdownEnter(ProductRatingsLocators.strategy,data["Strategy"])
            data["Strategy"] = self.getAttributeValue(ProductRatingsLocators.strategy_gettext)
        if "Product_Rating" in keys:
            assert self.spantypedropdown(ProductRatingsLocators.product_rating,data["Product_Rating"])




    def prod_ratings_allrecords_create_verify(self,data):
        testdata = data["Platform Availability Rating"]
        for i in testdata["Record_Type"]:
            testdata.update(data[i])
            testdata["One_Record_Type"]=i
            if testdata["One_Record_Type"]=="Platform Availability Rating":
                testdata.update(data["Platforms"])
            self.prod_ratings_home()
            self.log.info("Navigated to Organization tab")
            self.prod_ratings_newrecord(i)
            self.log.info("Navigated to Creation of new organization record page :"+ i)
            self.prod_ratings_fillrecord(testdata)
            self.log.info("Record created succesfully")

    def save_product_rating(self):
        for i in range(2):
            assert self.elementClick(ProductRatingsLocators.save_button)
            try:
                assert self.waitForElementInvisible(ProductRatingsLocators.save_and_new,timeout=3)
                break
            except:
                pass
        assert self.waitForElementDisplay(ProductRatingsLocators.prod_rating_record_page)

    def delete_product_rating(self):
        assert self.elementClick(ProductRatingsLocators.show_more_actions)
        assert self.elementClick(ProductRatingsLocators.delete_record)
        assert self.elementClick(ProductRatingsLocators.delete_record_confirm)
        time.sleep(2)
        assert self.waitForElementInvisible(ProductRatingsLocators.delete_record_cancel)

    def prod_ratings_verify_jsonkeys(self,data):
        keys=list(data.keys())
        assert self.elementClick(ProductRatingsLocators.edit_organization)
        if "Organization" in keys:
            assert data["Organization"]==self.getAttributeValue(ProductRatingsLocators.organization_display)
        if "Platform" in keys:
            assert data["Platform"]==self.getAttributeValue(ProductRatingsLocators.platform_display)
        if "Product" in keys:
            assert data["Product"]==self.getAttributeValue(ProductRatingsLocators.product_display)
        if "Status" in keys:
            assert data["Status"]==self.getText(ProductRatingsLocators.status_display)
        if "Rating_Last_Confirmed_On" in keys:
            assert data["Rating_Last_Confirmed_On"]==self.getAttributeValue(ProductRatingsLocators.rating_last_confirmed_on_display)
        if "SMA_Fee" in keys:
            assert data["SMA_Fee"]+"%"==self.getAttributeValue(ProductRatingsLocators.sma_fee_display)
        if "SMA_Minimum" in keys:
            assert "$"+data["SMA_Minimum"]==self.getAttributeValue(ProductRatingsLocators.sma_minimum_display)
        if "Model_Delivery" in keys:
            assert data["Model_Delivery"]==self.getText(ProductRatingsLocators.model_delivery_display)
        if "Rating" in keys:
            assert data["Rating"]==self.getText(ProductRatingsLocators.rating_display)
        if "Rating_Date" in keys:
            assert data["Rating_Date"]==self.getAttributeValue(ProductRatingsLocators.rating_date_display)
        if "Original_Product_Rating" in keys:
            assert data["Original_Product_Rating"]==self.getAttributeValue(ProductRatingsLocators.original_product_rating_display)
        if "Comments" in keys:
            assert data["Comments"]==self.getAttributeValue(ProductRatingsLocators.comments_display)
        # if "Prior_Rating" in keys:
        #     assert data["Prior_Rating"]==self.getAttributeValue(ProductRatingsLocators.prior_rating_display)
        if "Prior_Rating_Date_Change" in keys:
            assert data["Prior_Rating_Date_Change"]==self.getAttributeValue(ProductRatingsLocators.prior_rating_date_change_display)
        if "Strategy" in keys:
            assert data["Strategy"]==self.getAttributeValue(ProductRatingsLocators.strategy_display)
        if "Product_Rating" in keys:
            assert data["Product_Rating"]==self.getText(ProductRatingsLocators.product_rating_display)
        assert self.elementClick(ProductRatingsLocators.verification_cancel)
        assert self.waitForElementInvisible(ProductRatingsLocators.verification_save)


    def prod_ratings_editrecord_jsonkeys(self,data):
        keys=list(data.keys())
        assert self.elementClick(ProductRatingsLocators.product_rating_edit)
        time.sleep(1)
        if "Organization" in keys:
            assert  self.elementClick(ProductRatingsLocators.organization_clear)
            assert self.sendKeysdownEnter(ProductRatingsLocators.organization,data["Organization"])
            data["Organization"]=self.getAttributeValue(ProductRatingsLocators.organization_gettext)
        if "Platform" in keys:
            assert self.elementClick(ProductRatingsLocators.platform_clear)
            assert self.sendKeysdownEnter(ProductRatingsLocators.platform,data["Platform"])
            data["Platform"] = self.getAttributeValue(ProductRatingsLocators.platform_gettext)
        if "Product" in keys:
            assert self.elementClick(ProductRatingsLocators.product_clear)
            assert self.sendKeysdownEnter(ProductRatingsLocators.product,data["Product"])
            data["Product"] = self.getAttributeValue(ProductRatingsLocators.product_gettext)
        if "Status" in keys:
            assert self.spantypedropdown(ProductRatingsLocators.status,data["Status"])
        if "Rating_Last_Confirmed_On" in keys:
            if data["Rating_Last_Confirmed_On"]=="None":
                data["Rating_Last_Confirmed_On"]=self.getTodayDate()
            assert self.sendKeys(ProductRatingsLocators.rating_last_confirmed_on,data["Rating_Last_Confirmed_On"])
        if "Rating_Last_Confirmed_By" in keys:
            assert self.elementClick(ProductRatingsLocators.rating_last_confirmed_by_clear)
            assert self.sendKeysdownEnter(ProductRatingsLocators.rating_last_confirmed_by,data["Rating_Last_Confirmed_By"])
        if "SMA_Fee" in keys:
            if data["SMA_Fee"]=="None":
                data["SMA_Fee"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.sma_fee,data["SMA_Fee"])
        if "SMA_Minimum" in keys:
            if data["SMA_Minimum"]=="None":
                data["SMA_Minimum"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.sma_minimum,data["SMA_Minimum"])
        if "Model_Delivery" in keys:
            assert self.spantypedropdown(ProductRatingsLocators.model_delivery,data["Model_Delivery"])
        if "Rating" in keys:
            assert self.spantypedropdown(ProductRatingsLocators.rating,data["Rating"])
        if "Rating_Date" in keys:
            if data["Rating_Date"]=="None":
                data["Rating_Date"] = self.getTodayDate()
            assert self.sendKeys(ProductRatingsLocators.rating_date,data["Rating_Date"])
        if "Original_Product_Rating" in keys:
            if data["Original_Product_Rating"]=="None":
                data["Original_Product_Rating"]=self.get_random_number(2)
            assert self.sendKeys(ProductRatingsLocators.original_product_rating,data["Original_Product_Rating"])
        if "Comments" in keys:
            if data["Comments"]=="None":
                data["Comments"]=self.get_random_string(8)
            assert self.sendKeys(ProductRatingsLocators.comments,data["Comments"])
        if "Prior_Rating" in keys:
            if data["Prior_Rating"]=="None":
                data["Prior_Rating"]=self.get_random_number(3)
            assert self.sendKeys(ProductRatingsLocators.prior_rating,data["Prior_Rating"])
        if "Prior_Rating_Date_Change" in keys:
            if data["Prior_Rating_Date_Change"]=="None":
                data["Prior_Rating_Date_Change"] = self.getTodayDate()
            assert self.sendKeys(ProductRatingsLocators.prior_rating_date_change,data["Prior_Rating_Date_Change"])
        if "Strategy" in keys:
            assert self.elementClick(ProductRatingsLocators.strategy_clear)
            assert self.sendKeysdownEnter(ProductRatingsLocators.strategy,data["Strategy"])
            data["Strategy"] = self.getAttributeValue(ProductRatingsLocators.strategy_gettext)
        if "Product_Rating" in keys:
            assert self.spantypedropdown(ProductRatingsLocators.product_rating,data["Product_Rating"])