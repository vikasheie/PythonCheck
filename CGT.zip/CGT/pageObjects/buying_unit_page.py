import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.buying_unit_locators import BuyingunitLocators
from config import properties





class BuyingunitPage(BasePage):


    def buying_unit_home(self):

        assert self.javascriptClick(BuyingunitLocators.buying_unit_tab)
        assert self.waitForPresenceOfElement(BuyingunitLocators.buying_unit_home)

    def buying_unit_newrecord(self):
        time.sleep(3)
        assert self.elementClick(BuyingunitLocators.buying_unit_new)


    def buying_unit_fillrecord(self,data):
        data["Sales_Team_Name"]=self.get_random_string(8)
        assert self.sendKeys(BuyingunitLocators.sales_team_name,data["Sales_Team_Name"])
        data["Buying_Unit_Lead"] = self.get_random_string(8)
        assert self.sendKeys(BuyingunitLocators.buying_unit_lead, data["Buying_Unit_Lead"])
        assert self.elementClick(BuyingunitLocators.save_button)
        assert self.waitForElementInvisible(BuyingunitLocators.cancel_button)

    def buying_unit_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Sales_Team_Name" in keys:
            if data["Sales_Team_Name"]=="None":
                data["Sales_Team_Name"]=self.get_random_string(8)
            assert self.sendKeys(BuyingunitLocators.sales_team_name,data["Sales_Team_Name"])
        if "Buying_Unit_Lead" in keys:
            if data["Buying_Unit_Lead"]=="None":
                data["Buying_Unit_Lead"] = self.get_random_string(8)
            assert self.sendKeys(BuyingunitLocators.buying_unit_lead, data["Buying_Unit_Lead"])


    def save_buyingunit(self):
        assert self.elementClick(BuyingunitLocators.save_button)
        assert self.waitForElementInvisible(BuyingunitLocators.cancel_button)

    def asset_flow_validation(self,data):
        assert self.elementClick(BuyingunitLocators.assets_flow)
        for i in data["Assets"]:
            self.asset_values(i)
        for j in data["Flows"]:
            self.flow_values(j)

    def buying_unit_create_validate(self,data):
        testdata=data["Buying_Unit"]
        self.buying_unit_home()
        self.log.info("Navigated to Buying unit page")
        self.buying_unit_newrecord()
        self.log.info("Navigated to Buying unit New record page")
        self.buying_unit_fillrecord(testdata)
        self.log.info("Created new Buying Unit")
        self.asset_flow_validation(testdata)
        self.log.info("Validated the assests anf flow values")

    def getkeycheck(self, data):
        testdata = data["Buying_Unit"]
        keys=list(testdata.keys())
        print(type(testdata.keys()))
        if "Assets" in keys:
            print("Assets Present")
        if "Testing" in keys:
            print("----------")


