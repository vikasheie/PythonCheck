import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.campaigns_locators import CampaignsLocators
from config import properties





class CampaignPage(BasePage):


    def campaign_home(self):

        assert self.javascriptClick(CampaignsLocators.campaigns_tab)
        assert self.waitForPresenceOfElement(CampaignsLocators.campaigns_home)

    def select_new(self):
        time.sleep(3)
        assert self.elementClick(CampaignsLocators.campaigns_new)

    def campaign_newrecord(self,data):
        self.select_new()
        dyanamic_record_locator=(By.XPATH,"(//div/span[text()='"+data+"'])[last()]")
        assert self.elementClick(dyanamic_record_locator)
        assert self.elementClick(CampaignsLocators.record_next)

    def campaign_fillrecord(self,data):
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Campaign_Name"]=self.get_random_string(8)
            assert self.sendKeys(CampaignsLocators.campaign_name,data["Campaign_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.listtypedropdown(CampaignsLocators.type,data["Type"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.listtypedropdown(CampaignsLocators.status,data["Status"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.listtypedropdown(CampaignsLocators.approval_required,data["Approval_Required"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Description"] = self.get_random_string(8)
            assert self.sendKeys(CampaignsLocators.description,data["Description"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Budgeted_Cost"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.budgeted_cost_in_campaign,data["Budgeted_Cost"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Actual_Cost"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.actual_cost_in_campaign,data["Actual_Cost"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            data["Expected_Revenue"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.expected_revenue_in_campaign,data["Expected_Revenue"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1], data["Record_Type"][2]]:
            assert self.sendKeys(CampaignsLocators.start_date,data["Start_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert self.listtypedropdown(CampaignsLocators.sales_region,data["Sales_Region"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][2]]:
            assert self.listtypedropdown(CampaignsLocators.sales_channel,data["Sales_Channel"])
        if data["One_Record_Type"] in [data["Record_Type"][1]]:
            data["Website"]=self.get_random_string(5)+data["Website"]
            assert self.sendKeys(CampaignsLocators.website,data["Website"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1],data["Record_Type"][2]]:
            assert self.javascriptClick(CampaignsLocators.active_checkbox)
        assert self.elementClick(CampaignsLocators.saverecord)
        assert self.waitForElementInvisible(CampaignsLocators.save_and_new)
        assert self.waitForElementDisplay(CampaignsLocators.campaign_record_page)


    def add_campaign_member(self,default_option=1):
        assert self.elementClick(CampaignsLocators.related_tab)
        assert self.elementClick(CampaignsLocators.campaigns_add_contact)
        table_option=(By.XPATH,"(//table/tbody//td//span[@class='slds-checkbox--faux'])["+str(default_option)+"]")
        assert self.elementClick(table_option)
        assert self.elementClick(CampaignsLocators.contact_save)
        assert self.elementClick(CampaignsLocators.campaign_member_submit)
        time.sleep(2)
        assert self.waitForElementDisplay(CampaignsLocators.campaign_member_chart)
        # assert 1==self.getText(CampaignsLocators.contact_count)

    def campaigns_allrecord_create_verify(self,data):
        testdata = data["Marketing Event/Webinar Campaign"]
        for i in testdata["Record_Type"]:
            testdata.update(data[i])
            testdata["One_Record_Type"] = i
            self.campaign_home()
            self.log.info("Navigated to Campaigns tab")
            self.campaign_newrecord(i)
            self.log.info("Navigated to Creation of new campaigns record page :" + i)
            self.campaign_fillrecord(testdata)
            self.log.info("Created Campaign member"+i)
            self.add_campaign_member()
            self.log.info("Added Campaign Member to the created Campaign")

    def campaign_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Campaign_Name" in keys:
            if data["Campaign_Name"]=="None":
                data["Campaign_Name"]=self.get_random_string(8)
            assert self.sendKeys(CampaignsLocators.campaign_name,data["Campaign_Name"])
        if "Type" in keys:
            assert self.listtypedropdown(CampaignsLocators.type,data["Type"])
        if "Status" in keys:
            assert self.listtypedropdown(CampaignsLocators.status,data["Status"])
        if "Approval_Required" in keys:
            assert self.listtypedropdown(CampaignsLocators.approval_required,data["Approval_Required"])
        if "Description" in keys:
            if data["Description"] == "None":
                data["Description"] = self.get_random_string(8)
            assert self.sendKeys(CampaignsLocators.description,data["Description"])
        if "Budgeted_Cost" in keys:
            if data["Budgeted_Cost"] == "None":
                data["Budgeted_Cost"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.budgeted_cost_in_campaign,data["Budgeted_Cost"])
        if "Actual_Cost" in keys:
            if data["Actual_Cost"] == "None":
                data["Actual_Cost"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.actual_cost_in_campaign,data["Actual_Cost"])
        if "Expected_Revenue" in keys:
            if data["Expected_Revenue"] == "None":
                data["Expected_Revenue"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.expected_revenue_in_campaign,data["Expected_Revenue"])
        if "Start_Date" in keys:
            if data["Start_Date"] == "None":
                data["Start_Date"]=self.getTodayDate()
            assert self.sendKeys(CampaignsLocators.start_date,data["Start_Date"])
        if "Sales_Region" in keys:
            assert self.listtypedropdown(CampaignsLocators.sales_region,data["Sales_Region"])
        if "Sales_Channel" in keys:
            assert self.listtypedropdown(CampaignsLocators.sales_channel,data["Sales_Channel"])
        if "Website" in keys:
            if data["Website"] == "None":
                data["Website"]=self.get_random_string(5)+".testing.com"
            assert self.sendKeys(CampaignsLocators.website,data["Website"])
        if "Active" in keys:
            assert self.javascriptClick(CampaignsLocators.active_checkbox)
        if "Product" in keys:
            assert self.sendKeysdownEnterList(CampaignsLocators.product,data["Product"])
            data["Product"]=self.getText(CampaignsLocators.product_gettext)



    def save_campaigns(self):
        assert self.elementClick(CampaignsLocators.saverecord)
        assert self.waitForElementInvisible(CampaignsLocators.save_and_new)
        assert self.waitForElementDisplay(CampaignsLocators.campaign_record_page)

    def campaign_verifyrecord_jsonkeys(self,data):
        assert self.elementClick(CampaignsLocators.campaign_name_edit)
        keys=list(data.keys())
        if "Campaign_Name" in keys:
            assert data["Campaign_Name"]==self.getAttributeValue(CampaignsLocators.campaign_name_display)
        if "Type" in keys:
            assert data["Type"]==self.getText(CampaignsLocators.type_display)
        if "Status" in keys:
            assert data["Status"]==self.getText(CampaignsLocators.status_display)
        if "Approval_Required" in keys:
            assert data["Approval_Required"]==self.getText(CampaignsLocators.approval_required_display)
        if "Description" in keys:
            assert data["Description"]==self.getAttributeValue(CampaignsLocators.description_display)
        if "Budgeted_Cost" in keys:
            assert "$"+data["Budgeted_Cost"]==self.getAttributeValue(CampaignsLocators.budgeted_cost_in_campaign_display)
        if "Actual_Cost" in keys:
            assert "$"+data["Actual_Cost"]==self.getAttributeValue(CampaignsLocators.actual_cost_in_campaign_display)
        if "Expected_Revenue" in keys:
            assert "$"+data["Expected_Revenue"]==self.getAttributeValue(CampaignsLocators.expected_revenue_in_campaign_display)
        if "Start_Date" in keys:
            print(data["Start_Date"])
            print(self.getAttributeValue(CampaignsLocators.start_date_display))
            assert data["Start_Date"]==self.getAttributeValue(CampaignsLocators.start_date_display)
        if "Sales_Region" in keys:
            assert data["Sales_Region"]==self.getText(CampaignsLocators.sales_region_display)
        if "Sales_Channel" in keys:
            assert data["Sales_Channel"]==self.getText(CampaignsLocators.sales_channel_display)
        if "Website" in keys:
            assert data["Website"]==self.getAttributeValue(CampaignsLocators.website_display)
        if "Active" in keys:
            assert self.isElementSelected(CampaignsLocators.active_checkbox)

    def clone_campaign(self):
        assert self.elementClick(CampaignsLocators.clone_campaign)
        self.save_campaigns()

    def validate_product_campaign_linkage(self,title):
        assert self.javascriptClick(CampaignsLocators.product_page_link)
        assert self.elementClick(CampaignsLocators.product_page_related)
        time.sleep(1)
        self.webScroll(direction="down")
        assert self.javascriptClick(CampaignsLocators.campaigns_in_product_viewall)
        self.elementClick(CampaignsLocators.campaings_in_product_sort)
        campaign_name = (By.XPATH, "(//tbody/tr/th//a[text()='"+title+"'])[last()]")
        assert self.waitForPresenceOfElement(campaign_name)

    def validate_budget_fields(self):
        assert self.waitForElementDisplay(CampaignsLocators.budgeted_cost_in_campaign_underoverview)
        assert self.waitForElementDisplay(CampaignsLocators.actual_cost_in_campaign_underoverview)
        assert self.waitForElementDisplay(CampaignsLocators.expected_revenue_in_campaign_underoverview)

    def campaign_editrecord_jsonkeys(self,data):
        assert self.elementClick(CampaignsLocators.campaign_edit)
        keys=list(data.keys())
        if "Campaign_Name" in keys:
            if data["Campaign_Name"]=="None":
                data["Campaign_Name"]=self.get_random_string(8)
            assert self.sendKeys(CampaignsLocators.campaign_name,data["Campaign_Name"])
        if "Type" in keys:
            assert self.listtypedropdown(CampaignsLocators.type,data["Type"])
        if "Status" in keys:
            assert self.listtypedropdown(CampaignsLocators.status,data["Status"])
        if "Approval_Required" in keys:
            assert self.listtypedropdown(CampaignsLocators.approval_required,data["Approval_Required"])
        if "Description" in keys:
            if data["Description"] == "None":
                data["Description"] = self.get_random_string(8)
            assert self.sendKeys(CampaignsLocators.description,data["Description"])
        if "Budgeted_Cost" in keys:
            if data["Budgeted_Cost"] == "None":
                data["Budgeted_Cost"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.budgeted_cost_in_campaign,data["Budgeted_Cost"])
        if "Actual_Cost" in keys:
            if data["Actual_Cost"] == "None":
                data["Actual_Cost"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.actual_cost_in_campaign,data["Actual_Cost"])
        if "Expected_Revenue" in keys:
            if data["Expected_Revenue"] == "None":
                data["Expected_Revenue"]=self.get_random_number(3)
            assert self.sendKeys(CampaignsLocators.expected_revenue_in_campaign,data["Expected_Revenue"])
        if "Start_Date" in keys:
            if data["Start_Date"] == "None":
                data["Start_Date"]=self.getTodayDate()
            assert self.sendKeys(CampaignsLocators.start_date,data["Start_Date"])
        if "Sales_Region" in keys:
            assert self.listtypedropdown(CampaignsLocators.sales_region,data["Sales_Region"])
        if "Sales_Channel" in keys:
            assert self.listtypedropdown(CampaignsLocators.sales_channel,data["Sales_Channel"])
        if "Website" in keys:
            if data["Website"] == "None":
                data["Website"]=self.get_random_string(5)+".testing.com"
            assert self.sendKeys(CampaignsLocators.website,data["Website"])
        if "Active" in keys:
            assert self.javascriptClick(CampaignsLocators.active_checkbox)
        if "Product" in keys:
            assert self.sendKeysdownEnterList(CampaignsLocators.product,data["Product"])
            data["Product"]=self.getText(CampaignsLocators.product_gettext)

    def add_and_save_campaign_member(self,default_option=1,viewoption="None"):
        assert self.elementClick(CampaignsLocators.related_tab)
        if viewoption=="View All".lower():
            assert self.javascriptClick(CampaignsLocators.campaign_member_viewall)
        assert self.elementClick(CampaignsLocators.campaigns_add_contact)
        table_option=(By.XPATH,"(//table/tbody//td//span[@class='slds-checkbox--faux'])["+str(default_option)+"]")
        assert self.elementClick(table_option)
        assert self.elementClick(CampaignsLocators.contact_save)
        assert self.elementClick(CampaignsLocators.campaign_member_submit)

    def verify_campaign_member_added(self):
        assert self.waitForElementDisplay(CampaignsLocators.campaign_member_chart)

    def verify_campaign_member_error(self):
        assert self.waitForElementDisplay(CampaignsLocators.campaign_inactive_add_error)

    def get_count_of_campaign_members_added(self):
        self.waitForElementDisplay(CampaignsLocators.campaign_member_count)
        self.elementClick(CampaignsLocators.refresh_buuton_viewall)
        time.sleep(1)
        full_text=self.getText(CampaignsLocators.campaign_member_count)
        result = full_text.split(" ")
        count=result[0]
        return count

    def delete_campaign_members(self):
        assert self.javascriptClick(CampaignsLocators.show_actions_in_viewall)
        assert self.javascriptClick(CampaignsLocators.show_actions_delete)
        assert self.javascriptClick(CampaignsLocators.show_actions_delete_confirm)
        self.elementClick(CampaignsLocators.refresh_buuton_viewall)
        time.sleep(1)

