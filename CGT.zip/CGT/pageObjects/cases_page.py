import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.cases_locators import CasesLocators
from config import properties



class CasesPage(BasePage):


    def cases_home(self):

        assert self.javascriptClick(CasesLocators.cases_tab)
        assert self.waitForPresenceOfElement(CasesLocators.cases_home)

    def cases_newrecord(self,data):
        time.sleep(3)
        assert self.elementClick(CasesLocators.cases_new)
        dyanamic_record_locator=(By.XPATH,"(//div/span[text()='"+data+"'])[last()]")
        assert self.elementClick(dyanamic_record_locator)
        assert self.elementClick(CasesLocators.record_next)

    def cases_fillrecord(self,data):
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            assert self.listtypedropdown(CasesLocators.case_origin,data["Cases_Orgin"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            assert self.listtypedropdown(CasesLocators.status,data["Status"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1]]:
            data["US_Cases_Ranby"]=self.get_random_string(8)
            assert self.sendKeys(CasesLocators.us_cases_ranby,data["US_Cases_Ranby"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            assert self.sendKeysdownEnterList(CasesLocators.case_requestor,data["Case_Requestor"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            data["Subject"] = self.get_random_string(8)
            assert self.sendKeys(CasesLocators.subject,data["Subject"])
        if data["One_Record_Type"] in [data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][5]]:
            assert self.sendKeys(CasesLocators.internal_duedate,data["Internal_Duedate"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.priority,data["Priority"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][4], data["Record_Type"][5]]:
            data["Priority_Justification"] = self.get_random_string(8)
            assert self.sendKeys(CasesLocators.priority_justification,data["Priority_Justification"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][4], data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.type,data["Type"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.listtypedropdown(CasesLocators.subtype,data["Subtype"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][3], data["Record_Type"][4], data["Record_Type"][5], data["Record_Type"][6], data["Record_Type"][7]]:
            data["Description"] = self.get_random_string(8)
            assert self.sendKeys(CasesLocators.description,data["Description"])
        if data["One_Record_Type"] in [data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][5]]:
            data["Internal_Comments"] = self.get_random_string(8)
            assert self.sendKeys(CasesLocators.internal_comments,data["Internal_Comments"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.listtypedropdown(CasesLocators.shock_analysis_required,data["Shock_Analysis_Required"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.listtypedropdown(CasesLocators.gainloss_analysis_required,data["Gainloss_Analysis_Required"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.listtypedropdown(CasesLocators.muni_concentration,data["Muni_Concentration"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4]]:
            data["Webemail"] = self.get_random_string(8)+data["Webemail"]
            assert self.sendKeys(CasesLocators.webemail,data["Webemail"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][5], data["Record_Type"][6]]:
            assert self.sendKeysdownEnterList(CasesLocators.contact_name,data["Contact_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0], data["Record_Type"][1], data["Record_Type"][3]]:
            assert self.sendKeysdownEnterList(CasesLocators.related_product,data["Related_Product"])
        if data["One_Record_Type"] in [data["Record_Type"][1], data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][5]]:
            assert self.sendKeysdownEnterList(CasesLocators.organization_name,data["Organization_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert self.listtypedropdown(CasesLocators.platform,data["Platform"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            assert self.multiselectdropdown("Report Type",data["Report_type"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            data["Prepared_By"]=self.get_random_string(8)
            assert self.sendKeys(CasesLocators.prepared_by,data["Prepared_By"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            data["Prepared_For"]=self.get_random_string(8)
            assert self.sendKeys(CasesLocators.prepared_by,data["Prepared_For"])
        if data["One_Record_Type"] in [data["Record_Type"][2], data["Record_Type"][3], data["Record_Type"][4]]:
            data["Reason_For_Adjusted_Duedate"] = self.get_random_string(8)
            assert self.sendKeys(CasesLocators.reason_for_adjusted_duedate,data["Reason_For_Adjusted_Duedate"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            data["Investment_Amount"] = self.get_random_number(3)
            assert self.sendKeys(CasesLocators.investment_amount,data["Investment_Amount"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            assert self.listtypedropdown(CasesLocators.illustration_type,data["Illustration_Type"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            assert self.listtypedropdown(CasesLocators.dividents,data["Dividends"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            assert self.listtypedropdown(CasesLocators.cap_gains,data["Cap_Gain"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            assert self.listtypedropdown(CasesLocators.sales_charge,data["Sales_Charge"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.listtypedropdown(CasesLocators.channel,data["Channel"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.listtypedropdown(CasesLocators.level_of_effort,data["Level_Of_Effort"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.listtypedropdown(CasesLocators.papaerwork_in_good_order,data["Paperwork_In_Good_Order"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.listtypedropdown(CasesLocators.project_team,data["Project_team"])
        if data["One_Record_Type"] in [data["Record_Type"][4], data["Record_Type"][7]]:
            assert self.sendKeys(CasesLocators.desired_completion_by,data["Desired_Completion_By"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            data["Desired_Completion_Justification"] = self.get_random_string(8)
            assert self.sendKeys(CasesLocators.desired_completion_justification,data["Desired_Completion_Justification"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.listtypedropdown(CasesLocators.case_reason,data["Case_Reason"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.sendKeys(CasesLocators.project_start_date,data["Project_Start_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.sendKeys(CasesLocators.project_end_date,data["Project_End_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.listtypedropdown(CasesLocators.dual_contract_fee,data["Dual_Contract_Fee"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            data["Dual_Contract_Rational_Fee"]=self.get_random_number(3)
            assert self.sendKeys(CasesLocators.dual_contract_rational_fee,data["Dual_Contract_Rational_Fee"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            data["Complete"]=self.get_random_number(2)
            assert self.sendKeys(CasesLocators.complete,data["Complete"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.sendKeys(CasesLocators.target_date,data["Target_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.sendKeys(CasesLocators.ripped,data["Ripped"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            data["Buying_Unit_Team_Website"]=self.get_random_string(7)+data["Buying_Unit_Team_Website"]
            assert self.sendKeys(CasesLocators.buying_unit_team_website,data["Buying_Unit_Team_Website"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            assert self.listtypedropdown(CasesLocators.category,data["Category"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.focus,data["Focus"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.purpose,data["Purpose"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            data["RFP_DDQ_Name"]=self.get_random_string(8)
            assert self.sendKeys(CasesLocators.rfp_ddq_name,data["RFP_DDQ_Name"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.sendKeys(CasesLocators.information_as_of,data["Information_As_Of"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.source,data["Source"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.vehicle_type,data["Vehicle_Type"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.client_group,data["Client_Group"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.contracting_entity,data["Contracting_Entity"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.sendKeysdownEnterList(CasesLocators.advisor,data["Advisor"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.listtypedropdown(CasesLocators.frequency,data["Frequency"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.sendKeys(CasesLocators.client_due_date,data["Client_Due_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][6]]:
            assert self.listtypedropdown(CasesLocators.target_product_date,data["Target_Product_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][7]]:
            assert self.sendKeys(CasesLocators.execution_date,data["Execution_Date"])
        assert self.elementClick(CasesLocators.saverecord)
        assert self.waitForElementInvisible(CasesLocators.save_and_new)
        assert self.waitForElementDisplay(CasesLocators.case_record_page)

    def cases_allrecords_create_verify(self,data):
        testdata = data["Factor / Bond Analysis Request"]
        for i in testdata["Record_Type"]:
            testdata.update(data[i])
            testdata["One_Record_Type"]=i
            self.cases_home()
            self.log.info("Navigated to Cases tab")
            self.cases_newrecord(i)
            self.log.info("Navigated to Creation of new Cases record page :"+ i)
            self.cases_fillrecord(testdata)
            self.log.info("Record created succesfully")
        # i="Territory Realignment Request"
        # testdata.update(data[i])
        # testdata["One_Record_Type"] = i
        # self.cases_home()
        # self.log.info("Navigated to Cases tab")
        # self.cases_newrecord(i)
        # self.log.info("Navigated to Creation of new Cases record page :" + i)
        # self.cases_fillrecord(testdata)
        # self.log.info("Record created succesfully")