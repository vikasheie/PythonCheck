import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.tasks_locators import TasksLocators
from config import properties





class TasksPage(BasePage):


    def tasks_home(self):

        assert self.javascriptClick(TasksLocators.tasks_tab)
        assert self.waitForPresenceOfElement(TasksLocators.tasks_home)

    def tasks_newrecord(self):
        time.sleep(3)
        assert self.elementClick(TasksLocators.new_task_dropdown)
        assert self.elementClick(TasksLocators.tasks_new)

    def tasks_fillrecord(self,data):
        data["Subject"]=self.get_random_string(6)
        assert self.sendKeys(TasksLocators.subject,data["Subject"])
        assert self.listtypedropdown(TasksLocators.type, data["Type"])
        assert self.listtypedropdown(TasksLocators.quality_contact, data["Quality_Contact"])
        assert self.sendKeys(TasksLocators.comments, data["Comments"])
        assert self.sendKeys(TasksLocators.due_date, data["Due_Date"])
        assert self.listtypedropdown(TasksLocators.status, data["Status"])
        assert self.listtypedropdown(TasksLocators.priority, data["Priority"])
        assert self.elementClick(TasksLocators.save_button)
        assert self.waitForElementInvisible(TasksLocators.save_and_new)
        created_task = (By.XPATH, "(//span[text()='"+data["Subject"]+"'])[last()-1]")
        assert self.waitForElementDisplay(created_task)

    def tasks_deleterecord(self):
        assert self.elementClick(TasksLocators.delete_button)
        assert self.elementClick(TasksLocators.delete_confirm)
        time.sleep(2)

    def tasks_create_verify(self,data):
        testdata = data["New Task"]
        self.tasks_home()
        self.log.info("Navigated to tasks tab")
        self.tasks_newrecord()
        self.log.info("Navigated to Creation of new tasks record page")
        self.tasks_fillrecord(testdata)
        self.log.info("Tasks created successfully")
        self.tasks_deleterecord()
        self.log.info("Tasks deleted successfully")

    def tasks_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Subject" in keys:
            if data["Subject"]=="None":
                data["Subject"]=self.get_random_string(6)
            assert self.sendKeys(TasksLocators.subject,data["Subject"])
        if "Type" in keys:
            assert self.listtypedropdown(TasksLocators.type, data["Type"])
        if "Quality_Contact" in keys:
            assert self.listtypedropdown(TasksLocators.quality_contact, data["Quality_Contact"])
        if "Comments" in keys:
            if data["Comments"]=="None":
                data["Comments"]=self.get_random_string(6)
            assert self.sendKeys(TasksLocators.comments, data["Comments"])
        if "Due_Date" in keys:
            if data["Due_Date"]=="None":
                data["Due_Date"]=self.getTodayDate()
            assert self.sendKeys(TasksLocators.due_date, data["Due_Date"])
        if "Status" in keys:
            assert self.listtypedropdown(TasksLocators.status, data["Status"])
        if "Priority" in keys:
            assert self.listtypedropdown(TasksLocators.priority, data["Priority"])
        if "Assigned_To" in keys:
            assert self.elementClick(TasksLocators.remove_assignedto)
            assert self.sendKeysdownEnterList(TasksLocators.assigned_to, data["Assigned_To"])


    def save_tasks(self):
        assert self.elementClick(TasksLocators.save_button)
        assert self.waitForElementInvisible(TasksLocators.save_and_new)

    def confirm_task_created(self,data):
        created_task = (By.XPATH, "(//span[text()='" + data["Subject"] + "'])[last()-1]")
        assert self.waitForElementDisplay(created_task)

    def select_kanban(self,optionvalue):
        assert self.elementClick(TasksLocators.kanban_option_select)
        assert self.sendKeys(TasksLocators.kanban_search,optionvalue)
        option_select=(By.XPATH,"(//mark[text()='"+optionvalue+"']/../..)[last()]")
        assert self.elementClick(option_select)

    def verify_record_presence_inkanban(self,searchtext):
        time.sleep(2)
        assert  self.elementClick(TasksLocators.refresh_button)
        search_result=(By.XPATH,"(//span/../..//span[text()='"+searchtext+"'])[1]")
        assert self.waitForPresenceOfElement(search_result)
        assert self.javascriptClick(search_result)

    def tasks_editrecord_jsonkeys(self,data):
        time.sleep(1)
        assert self.elementClick(TasksLocators.tasks_edit)
        keys=list(data.keys())
        if "Subject" in keys:
            if data["Subject"]=="None":
                data["Subject"]=self.get_random_string(6)
            assert self.sendKeys(TasksLocators.subject,data["Subject"])
        if "Type" in keys:
            assert self.listtypedropdown(TasksLocators.type, data["Type"])
        if "Quality_Contact" in keys:
            assert self.listtypedropdown(TasksLocators.quality_contact, data["Quality_Contact"])
        if "Comments" in keys:
            if data["Comments"]=="None":
                data["Comments"]=self.get_random_string(6)
            assert self.sendKeys(TasksLocators.comments, data["Comments"])
        if "Due_Date" in keys:
            if data["Due_Date"]=="None":
                data["Due_Date"]=self.getTodayDate()
            assert self.sendKeys(TasksLocators.due_date, data["Due_Date"])
        if "Status" in keys:
            assert self.listtypedropdown(TasksLocators.status, data["Status"])
        if "Priority" in keys:
            assert self.listtypedropdown(TasksLocators.priority, data["Priority"])
        if "Assigned_To" in keys:
            assert self.elementClick(TasksLocators.remove_assignedto)
            assert self.sendKeysdownEnterList(TasksLocators.assigned_to, data["Assigned_To"])
