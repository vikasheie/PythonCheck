import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.activity_notes_locators import ActivityNotesLocators
from config import properties





class ActivityNotesPage(BasePage):


    def activity_notes_home(self):

        assert self.javascriptClick(ActivityNotesLocators.activity_notes_tab)
        assert self.waitForPresenceOfElement(ActivityNotesLocators.activity_notes_home)

    def activity_notes_newrecord(self):

        assert self.elementClick(ActivityNotesLocators.activity_notes_new)


    def activity_notes_fillrecord(self,data):
        data["Title"]=self.get_random_string(8)
        assert self.sendKeys(ActivityNotesLocators.title,data["Title"])
        assert self.spantypedropdown(ActivityNotesLocators.activity_type, data["Activity_Type"])
        assert self.spantypedropdown(ActivityNotesLocators.purpose, data["Purpose"])
        assert self.spantypedropdown(ActivityNotesLocators.next_steps, data["Next_Steps"])
        assert self.sendKeys(ActivityNotesLocators.next_step_due_date, data["Next_Step_Due_Date"])
        assert self.javascriptClick(ActivityNotesLocators.next_button)
        assert self.sendKeysdownEnterActivity(ActivityNotesLocators.organization_attended,data["Organization_Attended"])
        assert self.sendKeysdownEnterActivity(ActivityNotesLocators.contacts_attended, data["Contacts_Attended"])
        assert self.sendKeysdownEnterActivity(ActivityNotesLocators.topics_product_discussed, data["Topics_Product_Discussed"])
        assert self.javascriptClick(ActivityNotesLocators.save_button)
        assert self.waitForElementDisplay(ActivityNotesLocators.activity_note_record_page)


    def activity_notes_create_verify(self,data):
        testdata = data["New Activity"]
        self.activity_notes_home()
        self.log.info("Navigated to Activity Notes tab")
        self.activity_notes_newrecord()
        self.log.info("Navigated to Creation of new activity notes record page")
        self.activity_notes_fillrecord(testdata)
        self.log.info("Record created successfully")

    def activity_notes_fillrecord_jsonkeys(self,data):
        keys=list(data.keys())
        if "Title" in keys:
            if data["Title"]=="None":
                data["Title"]=self.get_random_string(8)
        assert self.sendKeys(ActivityNotesLocators.title,data["Title"])
        if "Activity_Type" in keys:
            assert self.spantypedropdown(ActivityNotesLocators.activity_type, data["Activity_Type"])
        if "Purpose" in keys:
            assert self.spantypedropdown(ActivityNotesLocators.purpose, data["Purpose"])
        if "Next_Steps" in keys:
            assert self.spantypedropdown(ActivityNotesLocators.next_steps, data["Next_Steps"])
        if "Next_Step_Due_Date" in keys:
            if data["Next_Step_Due_Date"] == "None":
                data["Next_Step_Due_Date"]=self.getTodayDate()
            assert self.sendKeys(ActivityNotesLocators.next_step_due_date, data["Next_Step_Due_Date"])
        assert self.javascriptClick(ActivityNotesLocators.next_button)
        if "Organization_Attended" in keys:
            organizations=[]
            for i in data["Organization_Attended"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.organization_attended,i)
                time.sleep(1)
            organization_text = self.getElementList(ActivityNotesLocators.organization_attended_text)
            for j in organization_text:
                organizations.append(j.text)
            data["Organization_Attended"] = organizations
        if "Contacts_Attended" in keys:
            contacts=[]
            for i in data["Contacts_Attended"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.contacts_attended, i)
                time.sleep(1)
            contact_text=self.getElementList(ActivityNotesLocators.contacts_attended_text)
            for j in contact_text:
                contacts.append(j.text)
            data["Contacts_Attended"]=contacts
        if "Topics_Product_Discussed" in keys:
            products = []
            for i in data["Topics_Product_Discussed"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.topics_product_discussed, i)
                time.sleep(1)
            product_text = self.getElementList(ActivityNotesLocators.topics_product_discussed_text)
            for j in product_text:
                products.append(j.text)
            data["Topics_Product_Discussed"] = products
        if "Opportunities_Discussed" in keys:
            opportunities=[]
            for i in data["Opportunities_Discussed"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.opportunities_discussed, i)
                time.sleep(1)
            opportunity_text=self.getElementList(ActivityNotesLocators.opportunities_discussed_text)
            for j in opportunity_text:
                opportunities.append(j.text)
            data["Opportunities_Discussed"]=opportunities
        if "Employees_Attended" in keys:
            employees=[]
            for i in data["Employees_Attended"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.employees_attended, i)
                time.sleep(1)
            employees_text=self.getElementList(ActivityNotesLocators.employees_attended_text)
            for j in employees_text:
                employees.append(j.text)
            data["Employees_Attended"]=employees
        if "Campaigns_Discussed" in keys:
            campaigns=[]
            for i in data["Campaigns_Discussed"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.campaigns_discussed, i)
                time.sleep(1)
            campaigns_text=self.getElementList(ActivityNotesLocators.campaigns_discussed_text)
            for j in campaigns_text:
                campaigns.append(j.text)
            data["Campaigns_Discussed"]=campaigns

    def save_activity_notes(self):
        assert self.javascriptClick(ActivityNotesLocators.save_button)
        time.sleep(1)
        assert self.waitForElementDisplay(ActivityNotesLocators.activity_note_record_page)

    def save_click_activity_notes(self):
        assert self.javascriptClick(ActivityNotesLocators.save_button)

    def activity_notes_history(self,option):
        assert self.elementClick(ActivityNotesLocators.related_tab)
        assert self.waitForElementDisplay(ActivityNotesLocators.activity_notes_history)
        header_list=self.getElementList(ActivityNotesLocators.activity_notes_history_header)
        print(header_list)
        list_value=[]
        original=self.getTableHeaderCount(header_list,"Original Value")
        new=self.getTableHeaderCount(header_list,"New Value")
        original_value=(By.XPATH,"//lightning-formatted-text[text()='"+option+"']/../../../../../../td["+str(original)+"]//lightning-formatted-text")
        new_value = (By.XPATH,"//lightning-formatted-text[text()='" + option + "']/../../../../../../td["+str(new)+"]//lightning-formatted-text")
        list_value.append(self.getText(original_value))
        list_value.append(self.getText(new_value))
        return list_value

    def getTableHeaderCount(self,header_list,value):
        count=0
        for i in header_list:

            if i.text==value:
                break
            count = count + 1
        return count



    def activity_notes_editrecord_jsonkeys(self,data):
        assert self.javascriptClick(ActivityNotesLocators.activity_notes_edit)
        keys=list(data.keys())
        if "Owner" in keys:
            assert self.sendKeys(ActivityNotesLocators.owner,data["Owner"])
        if "Title" in keys:
            if data["Title"]=="None":
                data["Title"]=self.get_random_string(8)
            assert self.sendKeys(ActivityNotesLocators.title,data["Title"])
        if "Activity_Type" in keys:
            assert self.spantypedropdown(ActivityNotesLocators.activity_type, data["Activity_Type"])
        if "Purpose" in keys:
            assert self.spantypedropdown(ActivityNotesLocators.purpose, data["Purpose"])
        if "Next_Steps" in keys:
            assert self.spantypedropdown(ActivityNotesLocators.next_steps, data["Next_Steps"])
        if "Next_Step_Due_Date" in keys:
            if data["Next_Step_Due_Date"] == "None":
                data["Next_Step_Due_Date"]=self.getTodayDate()
            assert self.sendKeys(ActivityNotesLocators.next_step_due_date, data["Next_Step_Due_Date"])
        assert self.javascriptClick(ActivityNotesLocators.next_button)
        if "Organization_Attended" in keys:
            self.remove_added_values(ActivityNotesLocators.organization_attended_remove)
            for i in data["Organization_Attended"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.organization_attended,i)
        if "Contacts_Attended" in keys:
            self.remove_added_values(ActivityNotesLocators.contacts_attended_remove)
            for i in data["Contacts_Attended"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.contacts_attended, data["Contacts_Attended"])
        if "Topics_Product_Discussed" in keys:
            self.remove_added_values(ActivityNotesLocators.topics_product_discussed_remove)
            for i in data["Topics_Product_Discussed"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.topics_product_discussed, data["Topics_Product_Discussed"])
        if "Opportunities_Discussed" in keys:
            for i in data["Opportunities_Discussed"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.opportunities_discussed, i)
                time.sleep(1)
        if "Employees_Attended" in keys:
            for i in data["Employees_Attended"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.employees_attended, i)
                time.sleep(1)

    def organization_contact_edit(self,data):
        keys=list(data.keys())
        if "Organization_Attended" in keys:
            try:
                self.remove_added_values(ActivityNotesLocators.organization_attended_remove)
            except:
                pass
            for i in data["Organization_Attended"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.organization_attended,i)
        if "Contacts_Attended" in keys:
            try:
                self.remove_added_values(ActivityNotesLocators.contacts_attended_remove)
            except:
                pass
            for i in data["Contacts_Attended"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.contacts_attended, data["Contacts_Attended"])
        if "Topics_Product_Discussed" in keys:
            try:
                self.remove_added_values(ActivityNotesLocators.topics_product_discussed_remove)
            except:
                pass
            for i in data["Topics_Product_Discussed"]:
                assert self.sendKeysdownEnterPress(ActivityNotesLocators.topics_product_discussed, data["Topics_Product_Discussed"])


    def remove_added_values(self,locator):
        remove_button=self.driver.find_elements(*locator)
        for i in remove_button:
            i.click()
            time.sleep(0.8)

    def select_opportunity(self, data):
        time.sleep(0.5)
        assert self.javascriptClick(ActivityNotesLocators.new_opportunity)
        assert self.waitForElementDisplay(ActivityNotesLocators.opportunity_record_select)
        assert self.dropdownSelectElement(ActivityNotesLocators.opportunity_record_select,selector=data)
        assert self.elementClick(ActivityNotesLocators.opportunity_next)

    def verify_opportunity_record_autopopulated(self):
        assert self.waitForElementDisplay(ActivityNotesLocators.opportunity_primary_contact_clear)
        assert self.waitForElementDisplay(ActivityNotesLocators.product_clear)
        assert self.elementClick(ActivityNotesLocators.opportunity_cancel)
        assert self.waitForElementInvisible(ActivityNotesLocators.opportunity_save)

    def verify_organization_record_autopopulated(self):
        assert self.waitForElementDisplay(ActivityNotesLocators.organization_name_clear)
        assert self.elementClick(ActivityNotesLocators.opportunity_cancel)
        assert self.waitForElementInvisible(ActivityNotesLocators.opportunity_save)

    def delete_record_inrightpanel(self,locator):
        assert self.javascriptClick(locator)
        assert self.javascriptClick(ActivityNotesLocators.rightpanel_record_delete)
        time.sleep(1)
        Alert(self.driver).accept()

    def verify_activity_notes_inrelated(self,locator,title):
        assert self.javascriptClick(locator)
        self.switchtoChildWindow()
        time.sleep(1)
        assert self.elementClick(ActivityNotesLocators.campaign_related_tab)
        self.javascriptClick(ActivityNotesLocators.campaign_date_filter)
        activity_notes=(By.XPATH,"//span[text()='Activity Notes']/../../../..//tbody/tr/th//a[text()='"+title+"']")
        assert self.waitForPresenceOfElement(activity_notes)

