import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
from pageObjects.base_page import BasePage
from locators.product_locators import ProductLocators
from config import properties





class ProdcutsPage(BasePage):


    def product_home(self):

        assert self.javascriptClick(ProductLocators.products_tab)
        assert self.waitForPresenceOfElement(ProductLocators.products_home)

    def product_newrecord(self,data):
        time.sleep(3)
        assert self.elementClick(ProductLocators.products_new)
        dyanamic_record_locator=(By.XPATH,"(//div/span[text()='"+data+"'])[last()]")
        assert self.elementClick(dyanamic_record_locator)
        assert self.elementClick(ProductLocators.record_next)

    def product_fillrecord(self,data):
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][1],data["Record_Type"][2],data["Record_Type"][3],data["Record_Type"][4],data["Record_Type"][5],data["Record_Type"][6]]:
            data["Name"]=self.get_random_string(8)
            assert self.sendKeys(ProductLocators.name,data["Name"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][5],data["Record_Type"][6]]:
            assert self.sendKeysdownEnter(ProductLocators.asset_class,data["Asset_Class"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][5]]:
            assert self.sendKeysdownEnter(ProductLocators.sub_asset_class,data["Sub_Asset_Class"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeysdownEnter(ProductLocators.strategy,data["Strategy"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Fund_Promotor"]=self.get_random_string(8)
            assert self.sendKeys(ProductLocators.fund_promotor,data["Fund_Promotor"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["Fund_Code"]=self.get_random_number(3)
            assert self.sendKeys(ProductLocators.fund_code,data["Fund_Code"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ProductLocators.pre_qualification_required,data["Pre_Qualification_Required"])
        if data["One_Record_Type"] in [data["Record_Type"][0],data["Record_Type"][3],data["Record_Type"][5]]:
            assert self.spantypedropdown(ProductLocators.status,data["Status"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ProductLocators.domicile,data["Domicile"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.spantypedropdown(ProductLocators.line_of_business,data["Line_Of_Business"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ProductLocators.fund_launch_date,data["Fund_Launch_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            assert self.sendKeys(ProductLocators.close_date,data["Close_Date"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["CUSIP"]=self.get_random_number(5)
            assert self.sendKeys(ProductLocators.cusip,data["CUSIP"])
        if data["One_Record_Type"] in [data["Record_Type"][0]]:
            data["BOSS_ID"]=self.get_random_number(5)
            assert self.sendKeys(ProductLocators.boss_id,data["BOSS_ID"])
        if data["One_Record_Type"] in [data["Record_Type"][2]]:
            data["Investment_Vehicle_Id"]=self.get_random_number(5)
            assert self.sendKeys(ProductLocators.investment_vehicle_id,data["Investment_Vehicle_Id"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            assert self.spantypedropdown(ProductLocators.category,data["Category"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            assert self.spantypedropdown(ProductLocators.channel,data["Channel"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            assert self.spantypedropdown(ProductLocators.region,data["Region"])
        if data["One_Record_Type"] in [data["Record_Type"][3]]:
            data["Non_Investment_Product_Id"]=self.get_random_number(4)
            assert self.sendKeys(ProductLocators.non_investment_product_id,data["Non_Investment_Product_Id"])
        if data["One_Record_Type"] in [data["Record_Type"][4]]:
            data["Platform_Suite_Id"]=self.get_random_number(3)
            assert self.sendKeys(ProductLocators.platform_suite_id,data["Platform_Suite_Id"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            data["Strategy_Id"]=self.get_random_number(3)
            assert self.sendKeys(ProductLocators.strategy_id,data["Strategy_Id"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            assert self.spantypedropdown(ProductLocators.insitutional_product_classification,data["Institutional_Product_Classification"])
        if data["One_Record_Type"] in [data["Record_Type"][5]]:
            data["Standard_Management_Fee"]=self.get_random_number(3)
            assert self.sendKeys(ProductLocators.standard_management_fee,data["Standard_Management_Fee"])
        assert self.elementClick(ProductLocators.save_button)
        assert self.waitForElementInvisible(ProductLocators.save_and_new)
        assert self.waitForElementDisplay(ProductLocators.product_record_page)

    def product_allrecords_create_verify(self,data):
        testdata = data["Product"]
        product_testdata=data["Asset Retention"]
        for i in testdata["Record_Type"]:
            testdata.update(data[i])
            testdata["One_Record_Type"]=i
            self.product_home()
            self.log.info("Navigated to Organization tab")
            self.product_newrecord(i)
            self.log.info("Navigated to Creation of new organization record page :"+ i)
            self.product_fillrecord(testdata)
            if i=="Product":
                product_testdata["Edit_Product"]=testdata["Name"]
            self.log.info("Record created succesfully")

    def product_fillrecord_jsonkeys(self,data):
        keys = list(data.keys())
        if "Name" in keys:
            if data["Name"]=="None":
                data["Name"]=self.get_random_string(8)
            assert self.sendKeys(ProductLocators.name,data["Name"])
        if "Asset_Class" in keys:
            assert self.sendKeysdownEnter(ProductLocators.asset_class,data["Asset_Class"])
        if "Sub_Asset_Class" in keys:
            assert self.sendKeysdownEnter(ProductLocators.sub_asset_class,data["Sub_Asset_Class"])
        if "Strategy" in keys:
            assert self.sendKeysdownEnter(ProductLocators.strategy,data["Strategy"])
        if "Fund_Promotor" in keys:
            if data["Fund_Promotor"] == "None":
                data["Fund_Promotor"]=self.get_random_string(8)
            assert self.sendKeys(ProductLocators.fund_promotor,data["Fund_Promotor"])
        if "Fund_Code" in keys:
            if data["Fund_Code"] == "None":
                data["Fund_Code"]=self.get_random_number(3)
            assert self.sendKeys(ProductLocators.fund_code,data["Fund_Code"])
        if "Pre_Qualification_Required" in keys:
            assert self.spantypedropdown(ProductLocators.pre_qualification_required,data["Pre_Qualification_Required"])
        if "Status" in keys:
            assert self.spantypedropdown(ProductLocators.status,data["Status"])
        if "Domicile" in keys:
            assert self.spantypedropdown(ProductLocators.domicile,data["Domicile"])
        if "Line_Of_Business" in keys:
            assert self.spantypedropdown(ProductLocators.line_of_business,data["Line_Of_Business"])
        if "Fund_Launch_Date" in keys:
            if data["Fund_Launch_Date"] == "None":
                data["Fund_Launch_Date"] = self.getTodayDate()
            assert self.sendKeys(ProductLocators.fund_launch_date,data["Fund_Launch_Date"])
        if "Close_Date" in keys:
            if data["Close_Date"] == "None":
                data["Close_Date"]=self.getTodayDate()
            assert self.sendKeys(ProductLocators.close_date,data["Close_Date"])
        if "CUSIP" in keys:
            if data["CUSIP"] == "None":
                data["CUSIP"]=self.get_random_number(5)
            assert self.sendKeys(ProductLocators.cusip,data["CUSIP"])
        if "BOSS_ID" in keys:
            if data["BOSS_ID"] == "None":
                data["BOSS_ID"]=self.get_random_number(5)
            assert self.sendKeys(ProductLocators.boss_id,data["BOSS_ID"])
        if "Investment_Vehicle_Id" in keys:
            if data["Investment_Vehicle_Id"] == "None":
                data["Investment_Vehicle_Id"]=self.get_random_number(5)
            assert self.sendKeys(ProductLocators.investment_vehicle_id,data["Investment_Vehicle_Id"])
        if "Category" in keys:
            assert self.spantypedropdown(ProductLocators.category,data["Category"])
        if "Channel" in keys:
            assert self.spantypedropdown(ProductLocators.channel,data["Channel"])
        if "Region" in keys:
            assert self.spantypedropdown(ProductLocators.region,data["Region"])
        if "Non_Investment_Product_Id" in keys:
            if data["Non_Investment_Product_Id"] == "None":
                data["Non_Investment_Product_Id"]=self.get_random_number(4)
            assert self.sendKeys(ProductLocators.non_investment_product_id,data["Non_Investment_Product_Id"])
        if "Platform_Suite_Id" in keys:
            if data["Platform_Suite_Id"] == "None":
                data["Platform_Suite_Id"]=self.get_random_number(3)
            assert self.sendKeys(ProductLocators.platform_suite_id,data["Platform_Suite_Id"])
        if "Strategy_Id" in keys:
            if data["Strategy_Id"] == "None":
                data["Strategy_Id"]=self.get_random_number(3)
            assert self.sendKeys(ProductLocators.strategy_id,data["Strategy_Id"])
        if "Institutional_Product_Classification" in keys:
            assert self.spantypedropdown(ProductLocators.insitutional_product_classification,data["Institutional_Product_Classification"])
        if "Standard_Management_Fee" in keys:
            if data["Standard_Management_Fee"] == "None":
                data["Standard_Management_Fee"]=self.get_random_number(3)
            assert self.sendKeys(ProductLocators.standard_management_fee,data["Standard_Management_Fee"])

    def save_product(self):
        assert self.elementClick(ProductLocators.save_button)
        assert self.waitForElementInvisible(ProductLocators.save_and_new)
        assert self.waitForElementDisplay(ProductLocators.product_record_page)